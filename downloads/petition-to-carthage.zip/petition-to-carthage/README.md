# Petition to Carthage

A single-player decision game run by Claude, set in the world of *Mare Non Nostrum* — an alternate history in which Carthage wins the First Punic War and builds a commercial empire instead of a territorial one.

You are the Carthaginian Council of Elders. One turn per year, from 125 BC to 105 BC. Each year a dispatch or petition arrives — a tariff dispute, a colonial complaint, a temple that has claimed ownership of the harbour gulls — and you choose one of four responses. Consequences accumulate: standing facts, committees that report back years late, idioms minted from your disasters, and a running chronicle by a historian who is confidently wrong about everything. After twenty years the whole record is bound into a book and judged by a historian writing generations later — who can see your policies but not your dice.

The register is deadpan Douglas Adams delivered through period paperwork. The paperwork never notices it is being funny.

## Requirements

Claude Code (CLI or desktop app). The game uses skills, local files for game state, and real dice rolls via the shell, so it needs Claude Code rather than the plain claude.ai chat interface.

## Setup

1. Unzip this folder anywhere and keep its structure intact.
2. Open Claude Code **with this folder as the working directory** (`cd` into it and run `claude`, or open it in the desktop app).
3. Say: **"Let's play Petition to Carthage."**

Claude will read the reference material and open the first year. A full game is twenty turns; you can stop at any point and resume later — game state lives in `runs/`, not in the conversation, so it survives across sessions.

## What's in the box

- `.claude/skills/petition-to-carthage/SKILL.md` — the game rules Claude runs.
- `reference/` — the lore Claude reads before playing:
  - `chapter4.md`, `chapter5.md`, `chapter7.md` — chapters from *Mare Non Nostrum* covering the game's era and its immediate past
  - `world_bible.md` — condensed background from the earlier chapters
  - `idioms.md` — the book's Appendix A, the quality bar for idioms the game may coin
  - `idiom_craft_lessons.md` — how idioms get minted, and the gate most candidates should fail
- `runs/` — where each playthrough's files go. Each run gets its own dated folder containing `book.md` (the record you can read) plus two hidden state files Claude keeps for itself.

## House rules

- Don't peek at the run's `ledger.md` or `turn-log.md` during play — they contain the odds, the rolls, and the queued consequences. After the final verdict, ask Claude to show you the turn-log if you want to see behind the curtain.
- The reference chapters are actual chapters from the book, so they contain spoilers for *Mare Non Nostrum* through chapter 7. The game only needs *Claude* to have read them.

*Mare Non Nostrum* and this game are by S.J. Barrett — [marenonnostrum.com](https://marenonnostrum.com).
