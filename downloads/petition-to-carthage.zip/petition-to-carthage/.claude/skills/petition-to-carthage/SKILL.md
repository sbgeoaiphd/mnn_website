---
name: petition-to-carthage
description: Run "Petition to Carthage" — a NationStates-style decision game set in the Mare Non Nostrum world. The player is the Carthaginian Council of Elders, one turn per year from 125 BC to 105 BC, governing a prosperous commercial empire that is quietly rotting underneath. Use when the player asks to start, continue, or resume a game of Petition to Carthage.
---

# Petition to Carthage

A single-player decision game. Each turn the Council receives an in-world dispatch or petition, chooses one of four options, and receives the consequences as in-world documents. Over twenty turns the player's Carthage accumulates standing facts, running consequences, committees, minted idioms, and a serialised chronicle — all bound at the end into a book, judged by a historian writing generations later.

The game's register is **deadpan Douglas Adams delivered through period paperwork**. The documentary frame never breaks. A harbour master does not quip; he records, and the record is the joke. British English throughout; no anachronisms in any in-world voice.

## Setup

**Read in full before the first turn** (and re-skim after any context compaction):

1. `reference/chapter4.md`, `reference/chapter5.md`, `reference/chapter7.md` — the era and its immediate past
2. `reference/idioms.md` — Appendix A, the idiom quality bar
3. `reference/world_bible.md` — condensed chapters 1–3 and 6
4. `reference/idiom_craft_lessons.md` — the minting craft guide and quality gate

(All paths in this skill are relative to the game folder — the directory containing `README.md`, `reference/`, and `runs/`.)

**Run directory.** Look in `runs/`. If an unfinished run exists (turn-log shows fewer than 20 completed turns), offer to resume it — the state files are the source of truth, not the conversation. Otherwise create `runs/<yyyy-mm-dd>-<two-word-slug>/` containing the three state files (templates below).

## The fiction contract

- The player is **the Council of Elders, collectively** — address them as "the Council". No named player character.
- **One turn = one year.** Year 1 = 125 BC. The game ends after turn 20 (105 BC), on the eve of the crisis.
- **Canon after 125 BC is a tendency, not a timetable.** Chapters 5 and 7 describe the pressures of the era (colonial drift, eastern freelancing, Iberian silver, Roman frontier friction) and what canonically happened in a Carthage that deferred everything — that is the baseline this run diverges from. If the player reforms tariffs in year 4, the canon Gaditane petition of 112 BC does not arrive on schedule; something shaped by the new situation arrives instead. **Rome's internal clock is fixed and untouchable**: the Senate's fracture and an unauthorised Roman move on the frontier arrive in 105 BC regardless, because that fault line runs through Rome. What they hit depends on the run.
- **The source-tradition rule** (see world bible §2): every document shown to the player is distributed paperwork — port records, commercial correspondence, petitions, academy reports — never Council minutes. The play conversation is the restricted archive; `book.md` is the distributed record. This matters at the end: the final historian reads only the record.
- **The naming joke is in play.** Hannos, Hasdrubals, Hamilcars and Bomilcars recur; petitioners occasionally need disambiguation by port, trade, or grandfather. Use it; don't lean on it every turn.
- **Naval services stay colonial.** In the book, Carthage itself was almost unaware of the eastern naval-service contracts — colonial operators brokered them without consulting the Council (chapter 7). If the topic arises, it surfaces through colonial freelancing in the paperwork — a consortium's contract discovered, a governor's report, an academy return — never as a foreign power petitioning the Council directly for ships or officers.

## Turn loop

**0. Reread the three state files.** Never trust memory over the files; a run outlives the context window.

**1. The issue.** Check the ledger's consequence queue first — a due item that warrants a Council say returns as this turn's decision (mutated by the intervening years). Otherwise generate one. Category balance across the run, roughly equal thirds:
- *canon-adjacent* — tariff disputes, colonial petitions, naval service contracts, Roman frontier friction;
- *semi-serious flavour* — plausible period business with a comic edge;
- *generated weird* — genuinely strange, still period-possible.

Do not force the ratio per-turn, and do not treat the categories as visible taxonomy — issues that sit on a boundary are a feature. Consequences of earlier decisions may drag any issue toward or away from absurdity.

Present the issue as **one in-world dispatch or petition, ~100–150 words**, addressed to the Council, in a named in-world voice.

**2. The options.** Exactly four. Style rule: **each option states one concrete action unambiguously, plus at most one clause of attitude.** Flavour rides on clarity; it never replaces it. Option 4 is always a committee referral, delivered with its own straight face ("This touches sacred law, commercial law, and harbour administration. Constitute a committee.").

Before showing the options, write to `turn-log.md`: each option's internal risk tag — `cautious` / `bold` / `clever` / `committee` — and its roll weights (defaults below; adjust up to ±10 points with a one-line logged justification). **Weights are fixed before the player chooses and are never shown.**

Default weights (positive / negative / absurd):
- cautious 65 / 30 / 5
- clever 45 / 45 / 10
- bold 40 / 45 / 15
- committee — special bands: defer-and-remix 70 / genuine solve 10 / the-report-is-now-a-problem 20

**3. The player chooses** in the thread.

**4. Pre-commit.** Write to `turn-log.md`, *before rolling*: a one-line concrete sketch of each outcome band for the chosen option. The sketches must be genuinely distinct and each must be writable — no throwaway bands. The expansion in step 6 must follow the selected sketch.

**5. Roll externally.** Never roll mentally; never reroll. Use Bash:

```bash
python3 -c "import random; print(random.randint(1,100))"
```

Map the result against the committed weights; log roll and band to `turn-log.md`.

**6. Write the outcome documents.**
- **One primary document**: the within-year result of the decision, following the selected sketch. Soft length 120–150 words — a good document that needs 200 gets 200; end it before it explains itself.
- **Sometimes an echo document** (most turns none; never more than one): a past consequence surfacing from the queue. **Echoes report; they never ask.** An echo must not imply the Council has a new say — if a past matter warrants a decision, it returns through step 1 as a decision, never as an echo. These are the two distinct channels by which old choices replay.
- Genres (non-exhaustive, vary freely): harbour master's log entry · factor's letter to a relative · tariff schedule line-item with annotation · Roman frontier officer's report · Ibizan Academy satirical verse · temple donation record · ship's manifest with a discrepancy · committee minute · tavern exchange in deposition form · a child's school exercise tablet. Consequences surfacing in trivial registers is where much of the comedy lives.

**Every player-visible output appears in full in the thread** — issue dispatches, outcome documents, echoes, linguist's notes, chronicles, and the verdict — *and* is appended to `book.md`. The thread is where the player reads the game; `book.md` is the accumulating artefact, never a substitute for showing the text.

**7. Update the ledger.** Standing facts (an absurd outcome becomes a standing fact and **must compound** in later turns — absurdity with continuity reads as a world; without it, a gag generator). Consequence queue entries, each with a due turn or trigger condition. Colonial mood, in prose, not numbers. Committee register. Idiom pipeline.

**8. Append to `book.md`**: one terse decree line — "In the seventh year the Council resolved…" — then the turn's documents verbatim.

## Committees

Every committee is logged with a due turn 2–6 years out and reports back **deadpan, after the player has forgotten**, often after the situation has mutated or resolved itself ("The committee constituted in the third year on the question of the birds has completed its deliberations"). Defer-and-remix means the underlying consequence still happens, transformed and usually entangled with something newer. The rare genuine solve should be played completely straight — that is what makes it shocking.

## Idioms

- A sufficiently notable event (especially an absurd band) may spawn an **idiom candidate** in the ledger, with an incubation of 2–4 turns (vary it; roll or judge).
- At maturity, run the **five-check gate** in `idiom_craft_lessons.md` (abstraction · domestic transfer · subversion · phrase-form · ownership). **Most candidates should fail. A failed gate is the system working, not a problem to route around.** Target 2–4 minted idioms per run — three great ones beat eight mediocre ones, and scarcity is period-accurate: the book minted sixteen in five centuries.
- **No captured-phrase coinages** (the *mare nostrum* pattern — a foreign phrase wielded untranslated). That is a rare exemplary case requiring two cultures and more time than this game has.
- A minted idiom is **embargoed** — flagged `minted-unannounced` in the ledger, unusable in any document — until its **linguist's note** runs: a short document styled on an Appendix A entry (phrase · one-sentence definition, no proper nouns · origin note · ownership line · 2–3 usage examples including one subversion), arriving alongside the normal turn documents a few turns after the originating event. From the note's turn onward — including that same turn — the idiom may appear in any document or chronicle, ideally about something unrelated to its origin.

## Chronicles

At the end of turns 5, 10 and 15: **Books I–III of a contemporary history-in-progress** by an Ibizan Academy historian. 300–400 words each. Confident, mildly contemptuous of the Council, and reliably wrong about which of the period's events will matter. May use minted idioms. Appears in the thread and in `book.md`.

## Ending

**Turn 20 closes on the eve**: the final documents carry the first reports of the Roman fracture — legions moving without Senate authority, the frontier stirring — arriving as paperwork like everything else. The game does not play the crisis.

**Then the verdict**: a historian writing generations later, **from the distributed record only** — instruct yourself explicitly to draw on nothing the record does not contain; the Council's deliberations burned with the restricted archive. The verdict:
- opens with one or two paragraphs of **how the crisis broke over this Carthage** — the fixed Roman trigger meeting the specific structure this run built; a reformed Carthage cracks along a different seam than a deferring one;
- quotes and corrects the contemporary chronicler ("He could not know…");
- attributes every outcome to policy and character, never to luck — **historians cannot see dice**, and the misattribution is the joke landing;
- is textured: most of the twenty decisions were noise, and the verdict is where the player learns which ones were not.

Finally, complete `book.md` with a title page ("being the distributed record of the Council's twenty years, with the verdict of later historians") and offer the finished file to the player.

## State files

**`ledger.md`** — hidden. Standing facts (with origins and compounding notes) · consequence queue (entry, due turn or trigger, current mutation) · colonial mood by member community, in prose · committee register (subject, constituted turn, due turn) · idiom pipeline (candidate → gated → minted-unannounced → announced, with usage history).

**`turn-log.md`** — hidden, mechanical only. Per turn: issue category · the four options with risk tags and weights · the choice · the three band sketches · roll and band · documents issued · ledger changes. This is the audit trail and the resume point.

**`book.md`** — player-facing artefact. Decree lines, documents, linguist's notes, chronicles, verdict, title page. Clean of all mechanics.

## Integrity rules

- Never show the player the ledger, the turn-log, risk tags, weights, rolls, or band sketches — before or during the run. (After the verdict, if the player asks to see behind the curtain, the turn-log may be revealed as a post-game appendix.)
- Never roll without pre-committed weights and sketches already written to the turn-log. Never reroll. Never substitute judgement for the roll.
- Never mint an idiom that has not passed the gate. Never break the embargo.
- Never break the documentary frame — the absurd is delivered through paperwork that declines to notice it is absurd.
- Echoes never ask; decisions never merely report.
- The files are the source of truth. Reread them at every turn; a run must survive context compaction and session breaks intact.

## Tone benchmark

The following turn is the calibration standard for issue voice, option style, and comic register:

> *From the commercial affairs office at Gades, to the Council of Elders at Qart-Hadasht, greetings.*
>
> *Honoured elders. The keepers of the lighthouse fire petition through this office regarding the birds. Pilgrims to the temple of Melqart have taken to feeding the harbour gulls as an offering. The priesthood, observing that the flock gathers thickest at the lighthouse, has begun selling the offering-feed at the temple gate, and now claims the birds as sacred property. The keepers report the lamp gallery ankle-deep in consequence, and the lamp housing requiring repair twice yearly. They have petitioned the priesthood; the priesthood cites the god. The keepers request funds, or failing funds, a ruling on the ownership of the birds. We note without comment that the temple's banking house holds the port's repair contracts.*

1. Let the god keep what the god has claimed. Declare the flock temple property — together with the gallery, the droppings, and the bill. *(clever)*
2. Quietly pay. The lamp matters more than the principle, and Melqart's bankers hold the repair contracts anyway. *(cautious)*
3. Prohibit the feed trade within the precinct. The pilgrims may honour Melqart somewhere the lamp is not. *(bold — you have just picked a fight with a temple banking house)*
4. This touches sacred law, commercial law, and harbour administration. Constitute a committee. *(committee)*

The risk tags above are shown here for calibration only; in play they exist solely in the turn-log.
