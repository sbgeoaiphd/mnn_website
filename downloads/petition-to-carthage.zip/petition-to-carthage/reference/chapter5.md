# Mare Non Nostrum
## An Alternate History of the Mediterranean

### Chapter Five: Imperialism by Invoice

If you had stood on the great sea wall of Carthage in the spring of 125 BC and looked out across the harbour, you would have seen something that no city on earth could match.

Three hundred warships at anchor or in covered sheds. Beyond them, in the commercial harbour, perhaps five hundred merchant vessels — round-hulled grain ships from the Tunisian Cape, sleek galleys from the Iberian silver run, heavy-timbered Atlantic traders built to survive the open ocean beyond the Pillars of Hercules. Dockyards, ropewalks, sailmakers' lofts, the bronze foundries that cast ram fittings and anchor stocks. A naval academy whose graduates commanded fleets from the Ma'arab to the coast of Syria. And behind all of it, rising on the Byrsa hill, a city of perhaps three hundred thousand people — the largest, richest, most cosmopolitan metropolis west of Alexandria.

This was Carthage after a century of unchallenged maritime supremacy, and it was magnificent.

---

But magnificence, like wealth, is easier to describe than to explain. How did Carthage get here? What did a hundred years of owning the western sea actually produce? The answer begins — as most things in Carthage began — with money.

Before we get to the tariff schedules, start with the dirt. The Tunisian Cape — the agricultural heartland stretching from the Medjerda valley to the Cap Bon peninsula — was the most productive farmland in North Africa, and it had been feeding Carthage since the city's founding. Grain, olives, livestock, worked by Libyan tenant farmers on estates owned by Carthaginian citizens, producing surpluses that provisioned the navy and fed a growing capital. Behind the coast, in the interior, the Numidian kingdoms provided the other thing Carthage could not manufacture: cavalry. Numidian horsemen were an essential component of every Carthaginian army, and their fragmented tribal kingdoms — never unified, always competing — existed in a patron-client relationship with Carthage that kept them dependent without making them citizens. Carthage bought their loyalty the same way it bought everything else: reliably, at a fair price, with the understanding that the alternative suppliers were worse.

But the land, productive as it was, was finite. What was not finite — what turned Carthage from a rich city into something without precedent — was the sea.

The economics of Carthaginian supremacy from the late third century BC onward were, at their core, simple. Carthage controlled the sea lanes. Everyone who used the sea lanes paid Carthage.

The system that had emerged after the Roman war — gradually, through commercial practice rather than formal decree — was a network of port agreements, tariff schedules, and navigational licences that collectively amounted to the most comprehensive maritime regulatory framework the ancient world had ever seen. The reader who has followed this story from Bomilcar's raiding campaign will have noticed a rhythm by now: Carthaginian tariffs, Carthaginian inspections, Carthaginian port fees. Get used to it. This is what Carthaginian dominance actually looked like — not a fleet on the horizon but a man with a wax tablet and a tariff schedule, standing on a dock, asking to see your cargo manifest. The empire was the paperwork. If you wanted to ship grain from Egypt to Iberia, you paid Carthaginian port fees at every stop. If you wanted to move silver from the mines of southern Iberia to the markets of the eastern Mediterranean, your cargo travelled in Carthaginian-inspected holds, weighed on Carthaginian-certified scales, and was taxed at Carthaginian-administered ports. If you wanted to fish the waters off Sardinia, you bought a Carthaginian licence.

Not every transaction was Carthaginian. The system was not a monopoly in the crude sense. Greek merchants still traded, Italian ships still sailed, independent operators of a dozen nationalities still worked the sea. But they all operated within Carthaginian rules, and they all paid for the privilege. In modern terms, it was a regulatory empire — less dramatic than territorial conquest but considerably more profitable.

---

The revenue was staggering. The estimates that survive — mostly from Carthaginian port records, though Greek merchants corroborate the scale — suggest that Carthage's annual income from maritime tariffs and port fees alone rivalled the entire tax revenue of the Ptolemaic kingdom of Egypt. This is probably overstated, but the direction is right. Carthage was generating wealth on a scale that dwarfed anything the western Mediterranean had previously seen, and it was doing it without the enormous military expenditure that territorial empires required.

This had consequences. Lots of them.

The first and most visible consequence was building. Carthage in 125 BC looked nothing like the Carthage of 260 BC, because a century of maritime wealth had physically transformed the city.

The great harbour — already impressive before the war — had been expanded twice, first in the 210s and again in the 170s. The military harbour — the famous circular basin with its central island admiralty, sheltering a hundred and seventy warships in individual covered slips — had been joined by a second circular basin, built in the 170s on the same proven design. Carthage's engineers knew how to build it, having done it once already, and the second was faster and cheaper than the first. Between them, the twin basins could shelter over three hundred warships. The commercial harbour had been dredged and enlarged until it was the largest artificial port in the world, with stone quays stretching for over a mile and warehouse capacity that visiting merchants described, with a mixture of admiration and resentment, as limitless. That phrase — "admiration and resentment" — could serve as the unofficial motto of everyone who operated in the Carthaginian world in this period.

The city itself had grown outward and upward. The old Phoenician core — narrow streets, flat-roofed houses, the Byrsa citadel above, the ancient temples of Baal Hammon and Tanit in the lower city — was now surrounded by newer districts that showed Greek, Iberian, North African, and even Italic architectural influences. Carthaginian builders had always been pragmatic borrowers, and a century of cosmopolitan trade had given them access to every building tradition in the Mediterranean. The result was a city that looked like nowhere else: Phoenician bones, Greek proportions, North African colour, and a scale that belonged to Carthage alone.

But the most important thing Carthage was building wasn't in Carthage itself.

---

The Carthaginian colonial network of 125 BC was the most extensive maritime infrastructure the world had yet seen. And it had changed character in ways that would have surprised — and perhaps alarmed — the merchant oligarchs who had funded Bomilcar's war.

The old model of Carthaginian colonisation was the trading post. A harbour, a warehouse, a small permanent community of Carthaginian merchants, surrounded by indigenous peoples with whom you traded. You didn't govern. You didn't settle in large numbers. You maintained a commercial relationship and extracted value from it. This model had worked for centuries and had built the original Carthaginian trading network from the Levant to the Atlantic.

The new model was different, and it had emerged from the accumulated pressure of a century of success. This is how empires actually grow — not through the grand plans of great men, but through a thousand small decisions by people solving immediate problems, each solution creating the conditions for the next one.

The problem, bluntly, was people. Carthage was rich, and rich cities attract migrants. By the late 200s, the population of Carthage itself was straining the city's capacity — water supply, food, sanitation, housing. The surrounding agricultural hinterland in the Tunisian Cape was productive but finite. Carthage needed places to put people, and the trading posts weren't designed for settlement on any significant scale.

The solution evolved differently in different places, but the pattern was broadly consistent: trading posts became towns, towns became cities, and cities became, over time, something that Carthage had never really had before — genuine overseas communities that were Carthaginian not just commercially but culturally.

Gades — modern Cádiz, on the Atlantic coast of Spain — was the flagship example. Originally a Phoenician colony older than Carthage itself, Gades had always been an important node in the western trading network. But by 125 BC it had grown into a major city in its own right, with a population of perhaps fifty thousand, its own shipyards, its own merchant fleet, and a cultural life that blended Phoenician tradition with Iberian and Greek influences. The temple of Melqart at Gades was one of the great pilgrimage sites of the western Mediterranean — merchants came from as far as Egypt to make offerings before major voyages, and the priesthood had accumulated enough wealth to function as a de facto banking institution.

Cartagena (Punic *Qart-Hadasht* — "New Town," though we'll come back to that) had been founded by the Barcid family in the 220s as a base for their Iberian ambitions. After Hasdrubal's Sicilian adventure and the political retreat of the expansionist faction, Cartagena had reinvented itself as a commercial hub, the gateway to the Iberian silver mines and the principal port of the western Mediterranean. Between them, Gades and Tingis — the old Phoenician foundation on the African side, modern Tangier — controlled both pillars of the Strait of Hercules, and everything that passed between the Atlantic and the Mediterranean moved under their collective gaze. Tingis was the quieter partner, very much second to Gades in commercial weight, but strategically significant: a real city with a real Carthaginian community, watching the strait from the south while Gades watched from the north.

Cartagena was smaller than Gades but more dynamic — a boomtown energy, new money, a population that was aggressively mixed: Carthaginian merchants, Iberians, Greek craftsmen, Numidian soldiers who had stayed after their service ended and married local women.

The Balearic Islands — Ibiza (*Iboshim* in Punic), Mallorca, Menorca — had been Carthaginian since before anyone could remember, but they too had transformed. Ibiza in particular had become something unexpected: a cultural centre, home to a school of Carthaginian literature and philosophy that drew scholars from across the western Mediterranean. There was something about the island's isolation, its beauty, its distance from the commercial pressures of Carthage itself, that attracted the kind of Carthaginian who wanted to think rather than trade. The Ibizan Academy produced the first systematic Punic-language histories of Carthage — self-critical, sophisticated, and surprisingly willing to question the merchant oligarchy's self-congratulatory narratives. Their works circulated widely through colonial copies, which is how most of them survive today.

And then there were the new places.

---

The Carthaginian settlement of the islands beyond the Pillars of Hercules is one of those events that later historians invested with far more drama than it probably had at the time. There was no grand expedition, no Council decree, no moment when someone unrolled a map and said: here. What happened was simpler and more Carthaginian than that. Someone needed a place to fill water barrels, and the place turned out to be extraordinary.

Carthaginian ships had been sailing the Atlantic coast of Africa for centuries. Hanno's famous voyage of exploration, sometime in the fifth century BC, had reached perhaps as far as modern Cameroon. The Atlantic trade — gold, ivory, exotic hides — was well established, and the ships that ran it routinely passed within sight of the mountainous islands that lay a few days' sail off the African coast.

Navigators knew they were there. Merchants had landed on them, occasionally, for water and repairs. The islands were volcanic, beautiful, and sparsely inhabited — Berber-descended pastoralists, arrived from the African coast at some uncertain earlier date, living in small scattered communities in the interiors and along the coasts of at least the larger islands. They kept goats and grew grain. They had no metal, no writing, and — crucially — no ships. Each island's population was essentially isolated from the others. From a Carthaginian captain's perspective, these were people who couldn't come out to meet you and had nothing you'd anchor for.

So the islands sat there, noted on sailing charts, occasionally useful, nobody's priority.

What changed was the Africa trade. As the Atlantic routes grew busier in the late third and early second centuries BC — more ships, longer voyages, heavier cargoes — the lack of a reliable provisioning stop between Gades and the gold coast became a practical problem. Ships needed fresh water, repairs, somewhere to wait out bad weather. The African coast offered anchorages but no permanent Carthaginian presence south of the Anti-Atlas. The islands, sitting a few days off that coast with deep natural harbours and abundant fresh water, were the obvious answer.

The first permanent settlement was not a colony. It was a supply cache that refused to leave.

Sometime around 190 BC — the exact date is uncertain, and sources disagree on whether the initiative was private or semi-official — a Gaditane merchant captain established a provisioning station on the northeastern coast of one of the two large central islands, in a natural harbour sheltered from the Atlantic swells by a volcanic headland. The story that survives: he left a few men, some stores, a cistern. When he returned the following season, they were still there, and they had planted a garden.

The Carthaginians called the island group the *Iyim Ma'arab* — the Western Islands — and the name stuck, though sailors shortened it to simply "the Ma'arab." The harbour settlement acquired the name that Carthaginian settlements always acquired: Kart-Hadasht, New Town — or rather *Qart*-Hadasht, though the Ma'arabi pronunciation was already drifting (the founders had been Gaditane sailors whose Punic was not metropolitan to begin with, and two generations of Berber-speaking wives had done the rest). Which is, yes, exactly what they had already named Cartagena, and for that matter exactly what Carthage itself is called in Punic, and always has been. The Carthaginians were not terribly original when it came to naming things. Since Carthage and Cartagena have acquired perfectly serviceable names of their own over the intervening centuries, we will use those and reserve the Punic for this newest Kart-Hadasht — our small contribution to a disambiguation problem that the Carthaginians themselves never bothered to solve.

What happened next surprised everyone, including the settlers.

The volcanic soil was extraordinarily fertile. Grapevines planted as an afterthought produced their first harvests within only a few years. Grain yields were double or triple what the same crops produced on the Tunisian Cape. The climate was mild year-round — no killing frosts, gentler summers than the African coast, reliable rainfall on the windward slopes. A Gaditane merchant who stopped at Kart-Hadasht expecting to buy water and found fresh wine, figs, and surplus grain is said to have remarked that the gods had hidden a garden at the edge of the world and forgotten to tell anyone.

Word travelled the way it always does: through sailors' talk in harbour taverns, through merchants' letters, through the restless arithmetic of people looking for opportunity. And there were a great many people looking for opportunity, because Carthage — as we have already discussed — had a population problem.

The migration was never centrally planned, but it didn't need to be. Libyan farmers squeezed off the Tunisian Cape by agricultural consolidation heard about soil that grew almost anything. Iberian craftsmen heard about a boomtown harbour that needed every trade. Retired Numidian soldiers heard about open land available for anyone willing to stay. Carthaginian citizens who couldn't afford property in the capital heard about islands where a man could plant a vineyard and own it outright. They came in tens and twenties on the Africa-trade ships, families with their tools and their seeds and their goats, and the odd chartered vessel carrying nothing but settlers and livestock. And they kept coming.

The indigenous islanders watched this happen with — as far as we can tell from the fragmentary record — a mixture of wariness and pragmatism. The Carthaginians wanted the coasts and the harbours. The pastoral communities lived mostly in the highlands and the interior valleys. There was land enough. The newcomers brought metal tools, pottery, woven cloth, and access to the wider Mediterranean trade; the islanders knew the terrain, the seasons, the water sources, and which slopes grew what. Intermarriage began within the first generation. Bilingual children within the second. By 125 BC, the distinction between settler and islander was blurring in the lowland towns, though pastoral communities persisted in the mountain interiors, living much as they always had, now with iron knives and Carthaginian cooking pots.

By 125 BC, the Ma'arab settlements — there were now communities on all seven islands, though the two arid eastern islands remained thinly populated — had a combined population of perhaps fifteen to twenty thousand. This was modest by Mediterranean standards. But the islands had already become something far more significant than a provisioning stop.

The harbour at Kart-Hadasht sat on the northeastern coast, sheltered by its volcanic headland, and it was busy. Ships bound for the gold coast of West Africa stopped to take on water, provisions, and the increasingly famous Ma'arabi wine. Ships returning from the south stopped to repair and rest. The settlement that had grown around the harbour had the character of port towns everywhere: multilingual, slightly disreputable, and possessed of an energy that the older, more established colonies lacked. But it also had something else — the productive hinterland of an island whose soil seemed incapable of disappointing, feeding not just its own population but provisioning the Africa trade and beginning to export surplus back to Gades and Cartagena.

The other large island, to the west — mountainous, thickly forested on its northern slopes, dominated by a volcanic peak so tall that Atlantic sailors used it as a landmark from a hundred miles out — was developing differently. Less port, more farmland. The deep valleys on the windward northern slopes were filling with vineyards and orchards, sheltered from the ocean gales in ravines where the volcanic soil was richest. It was quieter than Kart-Hadasht's island, more agricultural, and the indigenous highland communities there were larger and more intact. In time it would become the breadbasket of the archipelago, but in 125 BC it was still mostly potential — settlers arriving every season, land being cleared, the outlines of something substantial beginning to emerge. The cluster of smaller western islands, thickly forested and rich in fresh water, was developing more slowly still — valued for their timber and as watering stops, but not yet drawing settlers in any number.

It was the furthest permanent outpost of Mediterranean civilisation. Beyond it, there was only the Atlantic, and the African coast, and whatever lay further south in waters that no Carthaginian ship had yet fully mapped.

The colonists probably did not think of themselves as making history. They were farmers and sailors and merchants, doing what Carthaginians had always done: finding a place where the harbour was good and the soil was decent, and making it work.

---

In the Iberian interior, what happened during this century was more consequential than anything that happened on the sea.

Hasdrubal's Sicilian campaign in the 220s had won everything it set out to win — and discredited the Barcid model of military expansion more thoroughly than any defeat could have. Nine thousand dead, nearly five thousand talents spent, the best general of his generation killed storming a hilltop position. Sicily was Carthaginian, yes. Nobody in the Council wanted to talk about what it had cost. The Barcid Triumph, they called it, and the name was not a compliment.

But the campaign had not eliminated the underlying problem that the Barcids had correctly identified: Carthage controlled the Iberian coast, but the interior was a different country. And the interior was where the silver was.

The approach that emerged after the Barcid retreat was, characteristically, commercial rather than military. It was also, characteristically, slower, messier, and more effective.

Carthaginian merchants had been dealing with Iberian tribal elites for generations. The coastal trade was old and deep — Iberian silver and copper flowed to Carthage, and Carthaginian manufactured goods, wine, and luxury items flowed back. The tribal chiefs who controlled the mining regions had grown wealthy from this exchange, and wealth had changed them, as it always changes people. They wanted more. More goods, more prestige, more connection to the wider Mediterranean world that Carthage represented.

Carthage, after Hasdrubal, gave them what they wanted — not through conquest but through integration.

The mechanism was simple and ancient: intermarriage, education, and debt. Carthaginian merchants married the daughters of Iberian chiefs, creating family networks that spanned the cultural divide. The sons of prominent Iberian families were sent to Carthage, Cartagena, or Gades for education — they learned Punic, studied navigation and commerce, worshipped at the temple of Tanit in Carthage or at the great shrine of Melqart in Gades alongside Carthaginian boys. They went home bilingual, bicultural, and thoroughly enmeshed in Carthaginian commercial networks.

And the debt — the debt was the real engine. Iberian chiefs who wanted to expand their mining operations, build better fortifications, or simply maintain their status in an increasingly competitive tribal landscape borrowed from Carthaginian financiers. The terms were not predatory, exactly, but they were effective: repayment in silver, at Carthaginian-set prices, through Carthaginian-controlled ports. Default meant loss of mining rights, which meant loss of status, which meant — in the hard world of Iberian tribal politics — loss of everything.

By the middle of the second century BC, large portions of the Iberian interior were Carthaginian in all but name. No legions had marched. No battles had been fought. The tribal elites were independent, proud, and increasingly Punic in language and religion, Carthaginian in economic orientation. The silver flowed, and Carthage took its cut at every stage.

It was imperialism by invoice, and it was devastatingly effective.

---

Syracuse is the question of what happens to a Greek city when the island it sits on becomes someone else's property.

Syracuse had been the jewel of Greek Sicily for more than five centuries — founded by Corinthian colonists around 733 BC, home to Archimedes and Theocritus, a city that had defeated an Athenian invasion and produced tyrants whose names had once echoed in the political vocabulary of every Greek-speaking city in the Mediterranean. It was proud, cultured, and accustomed to independence.

And then the Barcid Triumph happened, and the last Roman garrisons were finally taken, and Syracuse found itself alone on an island that was now, unambiguously, Carthaginian. Lilybaeum, on the western tip, was already the main Carthaginian naval base in Sicilian waters — it had been since before the war. Syracuse was something else: a Greek city that now had to learn to live inside a Carthaginian world.

The Syracusans were pragmatists. They had survived Athenian invasion, Carthaginian siege, and Roman alliance, all before Bomilcar's war had redrawn the map. They could survive this. And Carthage, to its credit, made survival easy — because Carthage did not want Syracuse's obedience. It wanted Syracuse's harbour.

The accommodation happened in stages, and if you squinted, it almost looked voluntary. In the years immediately after the campaign, Carthaginian merchants established permanent offices near the Great Harbour. Trade agreements were signed — port access, tariff schedules, navigational licences. Syracusan ships gained preferential access to the western trade routes. The terms were generous, because generosity was cheaper than a garrison and considerably more profitable.

By the 210s, the relationship had deepened into something structural. Carthaginian ships used the Great Harbour as a forward anchorage for the eastern trade. The temple of Tanit appeared on Ortygia, not far from the ancient temple of Athena — not imposed, the Syracusans would insist, but *invited*, a courtesy to the Carthaginian merchant community. Syracusan shipwrights began building to Carthaginian naval standards, because those were the hulls that got contracts.

By 125 BC, Syracuse was functionally a Carthaginian client state, though no Syracusan would have used that phrase and no Carthaginian would have been foolish enough to say it aloud. The city retained its Greek institutions, its Greek language, its theatres and philosophical schools. The assembly still met. The coinage still bore Arethusa's profile. But the harbour master answered, in practice, to Carthage. The tariff schedule was set in Carthage. And the sons of Syracusan merchants learned Punic alongside Greek, because that was where the money was.

It was, depending on your perspective, either a graceful accommodation or a slow cultural death. Probably it was both.

Massalia — Marseille — went the other way. Rome's oldest western ally sat near the mouth of the Rhône, the natural gateway between the Mediterranean and the Gallic interior, and as Rome's continental empire grew, so did Massalia's importance — not as a Carthaginian client but as a Roman port. Its harbour operated under Roman law. Its merchants provisioned the legions in the north. When Massaliot traders sailed south or west into Carthaginian-regulated waters, they entered the Carthaginian system at that point — paid the tariffs, carried the licences, accepted the inspections. But the home port was Roman, the overland connections were Roman, and the money increasingly flowed north, not south. Massalia thrived, but it thrived as the place where Rome's continental economy met Carthage's maritime one — a hinge between two worlds, belonging fully to neither.

Sardinia went quieter still. Hasdrubal had pacified the island in 229 BC — eight thousand troops, eighteen months, the indigenous Sardinian interior brought to heel for the first time in Carthaginian history. It had been a bloody, unglamorous little campaign, and nobody wrote epics about it. But by 125 BC, Sardinia was simply, thoroughly Carthaginian. Grain from the Campidano plain, metals from the Iglesiente mines, timber from the mountain interior — all of it flowing through Carthaginian ports, taxed and weighed and recorded. The island that had resisted Carthaginian control for centuries was now so quietly, unremarkably Carthaginian that it barely warranted mention. Which is, of course, exactly how the most successful integrations work.

The pattern repeated, with local variations, across the rest of the western Mediterranean. Alalia in Corsica, the Greek settlements along the Iberian coast — all of them were drawn into the Carthaginian commercial system, retaining local character but operating within a framework that was unmistakably Punic. Further east, along the Libyan coast, the old Phoenician foundations at Leptis (modern Leptis Magna, Libya), Oea (modern Tripoli), and Sabratha (modern Sabratah, Libya) formed the quiet eastern wing of the Carthaginian world — commercially active, culturally conservative, closer in temperament to the mother city than to the upstart western colonies. West of Carthage, along the Algerian and Moroccan coasts, the Carthaginian presence thinned with distance: cities like Iol (modern Cherchell, Algeria) and Tipasa (modern Tipaza, Algeria) had permanent merchant communities, but the coast was mostly Mauretanian tribal territory with a Carthaginian commercial overlay, ports of call rather than ports of origin. The western Mediterranean was becoming, not through conquest but through commerce, a Carthaginian world.

---

Before we leave Carthage's century of ascendancy, there is the thing that later historians would argue mattered more than the ships or the silver or the colonies.

Carthaginian culture flowered.

Five chapters of tariff schedules and naval tactics can leave a misleading impression. Carthage was not just a trading empire with a good navy. The Carthage of the second century BC was producing art, literature, philosophy, and science at a level that rivalled anything in the Hellenistic world.

The agricultural treatise of Mago — the great work of Carthaginian practical science, twenty-eight volumes on farming, viticulture, livestock management, and land use — had been composed generations earlier but was now the foundation of a broader tradition of applied knowledge. Carthaginian engineers developed innovations in harbour construction, water management, and ship design that the Mediterranean wouldn't see improved upon for centuries. The lighthouse at Gades, built around 160 BC, was a marvel of engineering — a stone tower with a perpetual fire visible for fifteen miles at sea, the first true lighthouse in the Atlantic. The great Carthaginian contributions to civilisation were not temples or epic poems but a farming manual and a lighthouse.

The Ibizan Academy produced histories, philosophical dialogues, and a body of poetry in Punic that constitutes much of what we now consider the classical Carthaginian literary canon.

A note on terminology, since both words have now appeared in the same sentence. "Punic" is the language, the culture, and the people — the Semitic tongue that Carthage inherited from its Phoenician founders and that the Ibizan Academy refined into a literary instrument, but also the civilisation that spoke it, the world it built, the identity it carried. "Carthaginian" is the city and, by extension, the state — its ships, its tariffs, its political apparatus. The distinction maps roughly onto "Latin" and "Roman": Latin is what you speak, Roman is what you are, politically. For now the two categories overlap almost completely, because the city and the culture are nearly coextensive. They will not always be.

What survives suggests a literary culture that was introspective, mercantile in its metaphors — the sea as fate, trade as conversation, profit and loss as moral categories — and surprisingly comfortable with self-doubt. One fragment, attributed to a philosopher named Abdmelqart, reads: "We are a people who count well and pray badly, and the gods have given us the sea because they knew we would weigh it."

The worship of Tanit — the great mother goddess, consort of Baal Hammon — spread throughout the western Mediterranean as Carthaginian commercial influence spread. Tanit symbols appeared on pottery in Iberia, on coins in Sardinia, on votive offerings in Syracuse. The religion travelled the same routes as the trade goods, carried not by missionaries but by merchants' wives and sailors' prayers. By 125 BC, the sign of Tanit — a triangle topped by outstretched arms and a circle — was the most widely recognised religious symbol in the western Mediterranean.

Whether this amounted to a "Carthaginian civilisation" in the way we speak of Greek or Roman civilisation is a question that scholars in our timeline have debated endlessly, mostly because Carthage never got the chance to answer it. In this timeline, it did.

And the answer, by 125 BC, was yes.

Carthage in the late second century BC was not just a trading empire with a navy. It was a civilisation — messy, multilingual, pragmatic, and alive in a way that the clean marble certainties of the Greek world and the disciplined hierarchies of Rome were not. It was a civilisation that had been shaped by the sea the way Rome had been shaped by the land: practically, opportunistically, with an eye always on the horizon and a hand always on the scales.

It had its problems. The merchant oligarchy that ran the Council of Elders was calcifying into a hereditary aristocracy, more interested in preserving its privileges than in governing well. The gap between the great trading families and the ordinary citizens of Carthage was widening. The colonial settlements, growing in size and confidence, were beginning to develop interests that diverged from the mother city. The Iberian interior, for all its commercial integration, remained tribally organised and potentially volatile.

These were the problems of success, and they were real, and they would matter. But in 125 BC, standing on that sea wall, watching the ships come and go in the greatest harbour in the world, it was easy to believe that the system would hold forever.

It was easy to believe that the sea was enough.
