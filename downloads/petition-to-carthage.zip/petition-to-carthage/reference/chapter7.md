# Mare Non Nostrum
## An Alternate History of the Mediterranean

### Chapter Seven: Outgrown

In 119 BC, a Roman senator named Gaius Servilius Caepio stood up in the Senate and made an argument that nobody wanted to hear.

We know about the speech only because a Syracusan historian mentioned it decades later, in passing, while making a different point entirely. That's how the Roman record works — public debates survive in fragments, refracted through third parties, and the speeches that matter most are often the ones nobody thought worth preserving at the time. What Caepio argued, according to this source, was that Rome's Iberian frontier was untenable. The line of forts and roads that Rome maintained along the northeastern corner of the peninsula — territory it had acquired barely fifty years earlier, pushing through the Pyrenean passes as an afterthought of the Gallic conquest — was a drain on resources that produced nothing. The garrisons watched. The reports were filed. Nothing changed.

The Senate ignored him, because that is what the Senate did with uncomfortable truths about peripheral frontiers. The Rhine-Danube line was where careers were made, where the legions were, where the ambition of the Roman governing class was concentrated. Iberia was the last room in the house — the place you sent commanders who needed to be given something to do and legions the Senate wanted far from Rome.

But Caepio was right about the trajectory. The Iberian frontier was becoming a problem, and the reason had nothing to do with Rome.

It had to do with silver.

The silver mines of southern and central Iberia had been the economic engine of Carthaginian expansion for over a century. The mines at Cartagena, at Castulo, at a dozen smaller sites scattered through the Baetic ranges — their output underwrote the entire Carthaginian commercial system. Silver paid the navy. Silver funded the colonies. Silver bought the loyalty of Iberian tribal elites through the debt-and-intermarriage networks that Chapter Five described. Silver was the foundation of everything.

And the silver economy was expanding.

The richest southern deposits were beginning to show signs of depletion — not exhaustion, not yet, but declining yields that required deeper shafts, more labour, more investment for less return. Prospectors working the river valleys of central Iberia were finding new deposits: rich ones, closer to the surface, easier to work. These new mines were still deep in Carthage's commercial sphere — a hundred miles or more south of the Ebro, well beyond any Roman presence — but the expansion drew the whole Carthaginian commercial apparatus further into the interior. A Carthaginian financier would make an arrangement with a Celtiberian chief: fund the mining operation, provide the technical expertise, buy the output at agreed prices. The chief got rich. The financier got richer. And the commercial network that connected mine to port to market extended further north with every new deal.

It was the commercial ripple, not the mining itself, that reached the Roman frontier. Not Carthaginian soldiers. Not even, for the most part, Carthaginian merchants in person. What the Roman garrisons along the Ebro saw was subtler and, in its way, more unsettling: tribal trade networks that had always flowed in every direction were reorienting southward, carrying Punic goods into markets where Roman ones had circulated, pulling chiefs whose allegiances had been loosely Roman into a commercial gravity that pulled toward Carthage.

The frontier commanders sent reports. The Senate filed them, next to the ones from Caepio.

This was the slow-motion version of a border crisis, and it was infuriating precisely because there was nothing to fight. No army to engage, no city to besiege, no enemy to march against. Just money, flowing quietly through tribal networks, redrawing the map without anyone drawing a sword.

Two things about this Iberian situation explain what happened next.

The first is that this was familiar ground for Rome. Completely familiar. The Celtiberian tribes of the interior — their warrior aristocracies, their hilltop settlements, their metalwork and cattle-wealth and tribal politics — were the same broad Celtic world that Rome had spent the better part of a century conquering in Gaul. A Roman frontier officer transferred from the Rhine to the Ebro would have recognised the people, the politics, the dynamics. Different language, different landscape, same game. The Iberian frontier was, in every way that mattered, a natural extension of the continental project that had defined Rome since Pachynus. If Rome was going to expand somewhere new, this was the obvious place: contiguous, accessible by road, populated by people Roman officers already knew how to deal with.

The second is that the Iberian frontier was the one place in the world where Rome's reach and Carthage's influence came close enough to interfere with each other. Everywhere else, the division was clean — sea and land, each to its own. In Iberia, the line blurred. Rome had a frontier: the Ebro garrisons, the road from the Pyrenees, the hard edge of a continental state. Carthage had no equivalent line — just a gradient of Punic commercial influence that grew stronger the further south you travelled, strongest at the coast and attenuating inland and north, but never quite fading and recently fading less. Between the Roman frontier and the Punic coastal cities lay a broad belt of Celtiberian territory where neither power governed and both were felt. Any ambitious commander who went to Iberia would create friction with Carthaginian interests. Not because he intended to — though some would — but because the geography made it unavoidable.

This made the Iberian frontier the most dangerous place in the Mediterranean world. Not the most heavily armed. The most dangerous.

---

Meanwhile, in Rome, the Republic was eating itself.

The institutional crisis that had been building for decades came to a head in 115 BC with the Livian reforms — or, more precisely, with the violent failure of the Livian reforms.

Marcus Livius Drusus was, by the standards of the Roman aristocracy, a moderate. He had served with distinction on the Rhine frontier, governed a Gallic province without excessive corruption, and returned to Rome with a clear-eyed assessment of the Republic's problems. The problems were not subtle. The Italian allies who provided a substantial share of Rome's military manpower were demanding citizenship. The frontier legions were increasingly loyal to their commanders rather than the state. The urban poor were restless. The tax system was a carnival of exploitation. The Senate was deadlocked between factions that agreed on nothing except their mutual contempt.

Drusus proposed a package of reforms: citizenship for the Italian allies, land distribution for veterans, regulation of provincial governors, restructuring of the Senate's membership. It was comprehensive, pragmatic, and threatening to virtually every established interest in Rome.

He was murdered in the autumn of 115 BC. Stabbed in the entrance hall of his own house, by an assailant who was never identified — which in Roman politics meant that everyone knew who was responsible and no one could prove it.

The murder did not cause the crisis. The crisis was already there. But it removed the last plausible hope that the crisis could be resolved within the existing system, and what followed was a decade of escalating violence that would transform the Roman Republic beyond recognition.

First the streets. Political murders, gang warfare between factional enforcers, the kind of low-grade urban violence that makes governance impossible without ever quite forcing a reckoning. Then the allies.

The Italian allies revolted. Not all of them, and not all at once, but enough, in enough places, to force Rome into a vicious war on its own peninsula — the Social War. In the timeline you know, the dynamics were somewhat different, because Rome's military resources were spread across a maritime empire rather than a continental one. Here, the legions came home from the Gallic and Danubian frontiers and crushed the revolt in barely two campaigning seasons — professional frontier armies dealing with what a less specialised force might have struggled with for years — and the Senate purchased peace by granting most of the allies' demands. Italian citizenship was extended. The old alliance system was replaced by something broader and far more unwieldy.

And in the aftermath, the ambitious men emerged.

---

They matter, and they represent something more specific than generic strongmen with armies. They represent the two directions Rome could go when the continental consensus finally fractured.

Lucius Cornelius Nerva was an aristocrat from one of Rome's oldest families, a man of frozen ruthlessness. He had made his reputation in the Gallic revolt of the 120s, where he had crushed it with a combination of strategic brilliance and calculated brutality that left the surviving Gallic chiefs deeply respectful and deeply afraid. He was the Senate's man — or more precisely, he was the man the conservative Senate faction believed they could control, which is not the same thing.

Gaius Mamilius Turrinus was something else entirely. A *novus homo* — the first of his family to reach the Senate — risen through military merit rather than birth, beloved by his soldiers in a way that made the aristocracy profoundly nervous. He had served on the Danube frontier for fifteen years, longer than any commander in living memory, and the legions there were his in everything but name. Charismatic, populist, with an undisguised appetite for power. He was a product of the northern frontier establishment through and through — the Gallic-campaign, road-building, tribe-subduing world that had been Rome's centre of gravity for over a century.

In a different timeline — the one you know — these men might have been called Sulla and Marius. The parallels should not be pushed too far. The men were not the same. But the structural position was identical: two ambitious figures, each commanding the loyalty of professional armies, each representing a faction that believed the other's vision for Rome was an existential threat, operating within an institutional framework that had no mechanism for resolving the conflict peacefully.

But there is a difference from our timeline that matters enormously here: the existence of a third faction — a quieter one, which had been waiting a very long time.

The *mare nostrum* faction.

Chapter Six described them: the old-money families of the southern Italian coast, the aristocrats whose identity was tied to the Mediterranean, who burned a model Carthaginian ship every year on the anniversary of Pachynus and taught their children that the sea was stolen property. For over a century they had been a recognised minority in Roman politics, patient as stone, dismissed by the continental establishment as provincial dreamers.

Their man was a younger general named Publius Cassius Longinus.

Cassius came from exactly the background the *mare nostrum* faction produced — old southern Italian money, a family that traced its importance to the pre-Pachynus era, a man raised on stories of what Rome had lost. He was competent, cold, and possessed of a conviction that the continental consensus was not just strategically wrong but morally shameful. Where Turrinus thought about Iberia and Gaul and the familiar Celtic world, Cassius looked toward Greece.

He had four legions on the Illyrian frontier — the Illyrian frontier command, the quiet posting that the northern establishment treated as a backwater. From Cassius's perspective, the Illyrian frontier was not a backwater. It was a launching point.

Turrinus and Cassius were not allies. They did not coordinate. They represented fundamentally incompatible visions of what Rome should be, and the fact that they were both acting simultaneously was not a strategy — it was a symptom. The political system had fractured enough that two generals could independently pursue two different wars, pulling Rome in two directions at once, and no institution existed that could stop either of them.

Turrinus wanted to push south into Iberia — familiar territory, familiar people, the natural next step for a continental power that had run out of easy conquests in Gaul and the Balkans. His interest in Carthage looks, in retrospect, incidental. He needed a war. Iberia was where you found one if you were a continental general with a continental army. That the war would bring him into friction with Carthaginian commercial interests was a fact he would use politically — it made good speeches — but it was not his motivation. His motivation was the same thing that motivated every ambitious Roman commander since the Gallic conquest: expansion, triumph, power.

Cassius was after something different altogether. He wanted to cross the Adriatic, land in Greece, and prove that Rome could operate in the Mediterranean world. This was the *mare nostrum* dream enacted — not a pragmatic military calculation but the expression of a generational grievance, the southern coastal faction finally finding its moment in the wreckage of the constitutional order. The continental establishment thought it was insane. Cassius thought the continental establishment had spent a century and a half being wrong about the most important question in Roman strategy.

Neither man cared about the other's war.

---

Let us cross the sea — metaphorically, since the Romans still wouldn't — and look at what was happening in Carthage.

The Carthaginian crisis of the late second century was less dramatic than Rome's, which is precisely what made it more dangerous. Rome's problems produced violence, which at least had the virtue of clarity. Carthage's problems produced meetings.

The Council of Elders — the ruling body that had governed Carthage for centuries — had, by 115 BC, achieved a level of institutional sclerosis that would have impressed even the most cynical Roman senator. The same families had controlled the major seats for generations. Debate had calcified into ritual. The factions — the old naval and commercial establishments, and the increasingly significant colonial interest — had hardened into permanent blocs that traded favours and blocked reform with equal efficiency. Nothing could be decided because nothing could be agreed upon, and nothing could be agreed upon because every decision affected the balance of power between factions that had been deadlocked so long they had forgotten what they were originally fighting about.

The Carthaginian world was changing, and the Council was not changing with it.

The colonies were the most obvious pressure point. Gades, Cartagena, the Balearics — these were no longer outposts. They were cities, with populations, economies, and interests of their own. Gades in particular had grown into a commercial power that rivalled Carthage itself in certain sectors: the Atlantic trade, the tin route to Britain, the emerging gold trade with West Africa. The Gaditane merchant families were wealthy, confident, and increasingly resentful of a regulatory system that funnelled their profits through Carthaginian intermediaries and taxed them for the privilege.

The specific grievance was — what else? — tariffs. Carthaginian tariffs, Carthaginian inspections, Carthaginian port fees. The rates were designed, as they had always been designed, to ensure that Carthage itself captured a disproportionate share of the commercial surplus. This had been tolerable when the colonies were small and dependent. It was less tolerable when Gades had its own fleet, its own trade networks, and a merchant class that could do arithmetic.

In 112 BC, the Gaditane merchant council sent a formal petition to Carthage requesting a reduction in Atlantic trade tariffs and a greater degree of commercial autonomy. The petition was polite, detailed, financially literate, and completely ignored by the Council of Elders.

This was a mistake, though it didn't look like one at the time. The Council had been ignoring colonial petitions for decades. It was practically a tradition.

But the Gaditane petition marked the first time a major colony had formally, publicly, in writing, challenged Carthage's right to set the terms of trade. It was a crack in the assumption of centralised control, and cracks, left unrepaired, tend to spread.

Over the following decade, similar petitions arrived from Cartagena, from the Balearic settlements, and — most alarmingly — from the Carthaginian communities in Sardinia, which were close to the motherland and hard to dismiss as peripheral malcontents. The requests varied in specifics but shared a common theme: the old model, where Carthage commanded and the colonies complied, was no longer adequate for a commercial network that had outgrown its founder.

The Council's response was to form a committee. The committee deliberated for three years and produced a report recommending modest tariff adjustments. The adjustments were blocked by the commercial faction, which depended on the existing tariff structure for its income. The colonial representatives went home empty-handed.

None of this was violent. None of it was dramatic. It was, in fact, almost comically bureaucratic — the kind of institutional dysfunction with devastating long-term consequences.

---

Because while the Council was forming committees and blocking reforms, the colonies were quietly doing something much more significant: they were building their own relationships.

The Carthaginian eastern trade had always been managed from Carthage itself. Ships sailing to Egypt, to Rhodes, to the ports of the Levant and Asia Minor, departed from the great harbour and returned to it. The profits were taxed at Carthaginian rates and flowed through Carthaginian institutions.

What happened in the late second century was that the system developed leaks.

Gaditane merchants, frustrated by Carthaginian tariffs, began running their own ships into the eastern Mediterranean — not through Carthage but past it, sailing from Gades through the Strait, along the North African coast, directly to Alexandria. It was a far longer commitment for a single crew — the full run from the Atlantic to Alexandria without handing off to Carthaginian intermediaries — and it was technically illegal under Carthaginian commercial law. But the Carthaginian navy, stretched thin across the western Mediterranean and Atlantic, could not patrol every mile of African coastline, and the profits from cutting out the Carthaginian middleman were substantial.

This was, in miniature, exactly the kind of commercial freelancing that Carthage had spent a century preventing other nations from doing. The irony was not lost on the Gaditane merchants, who enjoyed it immensely.

More importantly, the eastern trade brought the Carthaginian colonies into direct contact with the Hellenistic world — with Ptolemaic Egypt, with the Rhodian trading republic, with the Seleucid territories. And these contacts produced something that the Council found far more alarming than lost tariff revenue: relationships.

Carthaginian merchants — not the Carthage-based establishment, but the independent colonial operators — began establishing permanent presences in eastern ports. A Gaditane trading house opened an office in Alexandria around 110 BC. A Balearic shipping consortium established a partnership with a Rhodian firm. Carthaginian silver, Iberian copper, Atlantic tin — goods flowing east through channels that Carthage itself did not control, into markets it did not regulate, creating networks that owed nothing to the mother city.

And in the eastern Mediterranean, these Carthaginian traders encountered something interesting: a market for naval services.

The Hellenistic kingdoms had always maintained their own fleets, but naval power was expensive and the kingdoms were perpetually strapped for cash — the Ptolemies drained by dynastic wars and declining agricultural yields, a diminished Seleucid kingdom bleeding territory and revenue to Parthian pressure on its eastern frontier. The Ptolemaic fleet, once the most powerful in the eastern Mediterranean, had declined through decades of underinvestment. The Seleucid navy was a joke. Only Rhodes maintained a serious naval capability, and even Rhodes was feeling the strain.

Carthaginian naval expertise — shipbuilding, crew training, tactical doctrine, the entire institutional apparatus that Bomilcar had built, and that his successors and their colonial imitators had maintained for over a century — was the most valuable export that Carthage didn't know it was selling. But the colonial merchants knew, because they were the ones fielding the requests. Could Carthage build us ships? Could Carthage train our crews? Could Carthage, perhaps, provide a squadron for a season or two, to deal with a piracy problem or a neighbour's aggression?

The Council of Elders, had it been consulted, would have had strong opinions about freelance Carthaginian naval forces operating in the eastern Mediterranean under the effective command of Hellenistic monarchs. The Council was not consulted. The colonial operators who were brokering these arrangements had learned, from a decade of ignored petitions, that consulting the Council was a waste of everyone's time.

By 105 BC, Carthaginian-built ships sailed in the fleets of three Hellenistic powers. Carthaginian-trained officers commanded Egyptian, Rhodian, and Athenian squadrons. And a network of naval-commercial relationships linked the Carthaginian colonial world to the eastern Mediterranean in ways that no one in Carthage had planned, no one in Carthage fully understood, and no one in Carthage could easily control.

The sea that Bomilcar had won was still Carthaginian. But the question of *which* Carthage it belonged to was no longer as simple as it had once been.

---

Back to Rome, and to 106 BC: the Iberian question had stopped being a problem and started being a crisis.

Turrinus gave a speech in the Forum that everyone recorded, because its importance was immediately obvious.

The speech was about Iberia. Turrinus argued that Rome's position on the peninsula was being undermined by Carthaginian money, that the tribal alliances Rome had maintained were being bought out from under them, that the frontier was collapsing not through military force but through commercial subversion. He demanded action — not war, not yet, but a reinforcement of the Iberian garrisons and a push south beyond the Ebro, into the Celtiberian interior where Punic commercial influence was displacing Roman.

It was a good speech. It was also, in its essentials, dishonest — framed to serve a purpose that had nothing to do with Iberia. Turrinus needed a war. Every ambitious general in Rome needed a war. The Gallic frontier was quiet, the Danubian frontier was stable, and the easy conquests were done. Iberia was the one place where a continental commander could find a fight, and the fact that the fight would involve Carthaginian interests gave it a political urgency that a mere tribal campaign in the Iberian interior would not have commanded. The Carthaginian angle was what made it sellable. It was what the Carthaginian merchant class would call framing — the decorative packaging around the real goods.

The Senate, controlled by Nerva's conservative faction, refused. Too expensive. Too provocative. The continental consensus, weakened but not yet broken, still held that Rome should consolidate its existing frontiers, not extend into new territory over Celtiberian trade goods.

Turrinus accepted the refusal with a public grace that fooled no one.

Because the speech had not really been about Iberia. It had been about the Senate's legitimacy — about the question of who got to decide where Roman legions went and what they did when they got there. And the answer to that question, in the Rome of 106 BC, was increasingly not the Senate.

While this played out in the Forum, Cassius was quieter. The *mare nostrum* faction had always been quieter — a minority does not survive a century by being loud. But Cassius was watching the same fracture in the constitutional order that Turrinus was exploiting, and he was drawing a different conclusion. Turrinus wanted Iberia, which was land, which was the continental game. Cassius wanted Greece, which was across water, which was the thing Rome had told itself for a century and a half that it would not do.

The Adriatic. Seventy-five miles of usually calm water. Fishing boats crossed it every day. Transport ships could manage it in fair weather without difficulty. The question had never been whether Rome *could* cross — any competent officer could get legions across that strait. The question was whether crossing was worth the consequences: the Carthaginian response, the supply problem, the political fallout from breaking the deepest taboo in Roman strategic culture.

Cassius believed the consequences were manageable, because Cassius believed something that the continental establishment did not: that the Carthaginian naval presence in the eastern Mediterranean was fragmented, distracted, and not actually under the Council's control. He had been reading the reports — the same reports everyone had access to — about colonial freelancing, about Carthaginian-trained officers serving in Hellenistic fleets, about a naval apparatus that was dispersing rather than concentrating. Where the northern establishment saw the east as none of Rome's business — the sea, again, irrelevant — Cassius saw opportunity. Carthage's eastern presence was commercial, not military. It was colonial entrepreneurs selling services, not Carthaginian admirals defending territory. If he could cross quickly, establish a position in Greece before the fragmented Carthaginian system could coordinate a response, he might hold.

It was a gamble. The continental establishment thought it was lunacy. But Cassius had spent his career being told that the *mare nostrum* dream was lunacy. And a faction that has nursed a grievance for a century and a half does not hesitate when its moment comes.

By the end of 106 BC, Rome was looking in two directions at once. Turrinus was engineering the political conditions for an Iberian campaign. Cassius, with his Illyrian legions, was thinking about fishing boats and calm water and the Greek coast.

Neither man cared about the other's war. Neither man's faction had any interest in the other's objectives. The continental establishment wanted land. The *mare nostrum* faction wanted sea. They were not pulling together. They were pulling apart.

---

And in Carthage, on a terrace overlooking the great harbour, a very old woman named Arishat read the reports from her agents in Rome and saw, with the instinct of a lifetime in commerce, exactly what was coming.

Her family had funded Bomilcar's original campaign — six generations back, a connection she traced with careful pride. In Carthage, lineage was capital. She was the matriarch of one of the great trading families. She had watched the Council ignore petitions and form committees and produce reports that went nowhere. She had watched the colonial network outgrow its governance. And now she was watching Rome crack along a fault line that ran between the land and the sea — the same fault line that had defined the Mediterranean for a century and a half.

She dictated a letter to her factor in Gades. The letter survives in the Gaditane commercial archive — it was, after all, exactly the kind of correspondence that the port records preserved. It said, in essence: the Romans are going to move. Probably south, into Iberia. Possibly east, into Greece. Possibly both. Prepare accordingly.

The factor in Gades read the letter and passed it to his counterpart in Cartagena, who passed it to the colonial naval commander in the Balearics, who passed it to his contacts in Rhodes and Alexandria.

Notice who was not in this chain of communication: the Council of Elders in Carthage.

The system that Bomilcar had built was about to be tested. But the people who would be doing the testing — on both sides — were not the ones sitting in the chambers where such decisions were supposed to be made.

---

::: later-voices
**Petition to Carthage**: a request that will never be answered, no matter how carefully crafted.[^petition_to_carthage]

> "I told the landlord about the roof six times." "And?" "Petition to Carthage." "Still leaking?" "In new places."

> "Send it to the governor." "He'll read it. It's not a petition to Carthage."
:::

[^petition_to_carthage]: Appendix A, 8. *Petition to Carthage*.
