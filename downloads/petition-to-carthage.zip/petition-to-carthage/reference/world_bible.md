# Petition to Carthage — World Bible

Condensed reference for running the game. Covers the essential content of chapters 1, 2, 3 and 6 of *Mare Non Nostrum*. Chapters 4, 5 and 7 and the idioms appendix are loaded in full alongside this file — do not duplicate them; defer to them where they overlap.

---

## 1. The divergence and the founding myth (chapters 1–3)

**Mylae, summer 260 BC.** Real history, and the last of it. Rome's first fleet — 130 quinqueremes of green timber, crewed by amateurs — meets the Carthaginian navy off Mylae and wins catastrophically, using the corvus: a 36-foot boarding bridge with an iron spike that pins an enemy ship and lets Roman legionaries do the thing they are best at. Carthage loses 50 ships. The divergence is what Carthage does next.

**Bomilcar Mago** was not at Mylae. A merchant captain from a minor branch of the declining Magonid networks — the middle routes, bulk goods, Sardinia trade — he was off Sardinia with **eleven ships**. On his own authority, while Mylae was being lost, he raided the port of Ostia at dawn: burned timber, hulls and naval stores, and was gone in under two hours. The insight: Rome's naval power was a supply chain, and supply chains can be cut. He sailed into Carthage with all eleven ships intact and a cold commercial argument, and the Council of Elders — merchants who understood the logic in their bones — gave him **thirty warships** and a deliberately vague mandate: secure naval superiority in the western Mediterranean by whatever means he judged necessary.

**The raiding campaign, 259–258 BC.** With 41 ships (later ~70, after the Council authorised 40 more in summer 258 and granted him operational independence, reporting directly to the Council), Bomilcar burned the western Italian coast from Etruria to Bruttium. The rotation was called **"the wheel"**: squadrons of three to five ships raiding a stretch of coast for a week or ten days, then rotating out; 15–20 ships active at any time. Fishing fleets, farms, estates, secondary shipyards — anything within an hour's march of the sea and not garrisoned. Fishing ceased as an industry; coastal agriculture contracted by a third; senators' estates burned; food prices rose in Rome. Meanwhile his concentrated striking force killed Roman ships in transit — always isolated groups, always three or four to one, always from the angle the corvus couldn't point. The corvus pins *both* ships: the Roman vessel that drops its bridge is immobilised and rammed by flanking vessels. Bomilcar's crews never boarded — they rammed and sank, no mechanism for mercy. A consul (Aulus Caiatinus — family attribution disputed) said fighting him was like fighting smoke.

**Cape Pachynus, late spring 257 BC.** Rome staked everything on one convoy: **eighty warships** and sixty transports carrying two legions and six months of supplies from Puteoli to Agrigentum, to win the Sicilian land war. Bomilcar's scouts saw it assembling. Decoy galleys peeled off eight escorts before the Strait of Messina. Bomilcar's 37 ships came out of the open sea — the direction no one watched — and annihilated the 20-ship rear guard in forty minutes; the escort commander sent 28 warships to chase him, and Bomilcar's feint back towards the convoy shattered their formation and killed 12 more. The remaining 24 escorts rounded the cape into **Carthalo's** 63 ships from Lilybaeum, positioned by signal-fire relay and waiting. All 24 destroyed; 45 of 60 transports sunk. The same week, 12 Carthaginian ships burned Brundisium — the first Carthaginian sail ever seen in the Adriatic.

**The canonical numbers:** fifty-six of eighty warships lost; five thousand legionaries drowned in armour, five thousand more stranded on Sicilian beaches with nothing; Carthaginian losses 22 ships. Rome quietly stopped: no decree, no speech — budgets frozen, timber rerouted, crews discharged. **Rome turned its back on the sea.**

**Bomilcar afterwards:** strategist emeritus — founded the naval academy, built the signal-station network, standardised shipbuilding. Died 238 BC, aged 57. His column stands in the harbour of Carthage, inscribed **HE GAVE CARTHAGE THE SEA**. Every Council debate in the game era happens in its shadow: he is the proof that one unglamorous man with accurate assessments can outvote a room, and the standing rebuke to complacency. (His victory was famously "unpaintable" — the temple paintings show Carthalo's battle line.)

## 2. How this world knows itself

Carthage documents what it *does*, exhaustively: tariff schedules, cargo manifests, harbour logs, requisition orders, loss ratios — copied and distributed to every port and academy in the network. Council deliberations are the opposite: recorded, but restricted to the central archives, never copied. What was said in the room stays in the room. **For the game: in-world documents shown to the player are port paperwork, academy reports, commercial correspondence, petitions — never Council minutes.** The Council reads; the world writes to it.

## 3. Rome in the game era (chapter 6)

By 125 BC Rome is a **Latin-Celtic continental civilisation**, not the Greco-Roman one we know. Roads from the Po Valley to the Rhine, Brittany to the upper Danube, plus a 40-year-old strip of eastern Iberia. Gaul took fifty grinding years (220s–170s) and remade the conqueror: La Tène patterns on Roman equipment and monuments, barrels instead of amphorae, beer alongside wine, heavy ploughs, timber architecture built for rain and cold. Religion drifted north — forest shrines on the military roads, river gods at bridge crossings, Jupiter merging with Celtic sky-gods. Literature is roads and frontiers: military manuals, legal treatises, farming guides. No Virgil, no Ovid. Greek influence is attenuated — texts without context, a foreign accomplishment like a gentleman's French. Greece itself is not feared but *irrelevant*: a maritime world a road-empire has no framework for.

**Two frontiers.** The Rhine-Danube line is where careers are made — the best legions, a hybrid frontier culture increasingly loyal to commanders rather than the Senate. The **Pyrenean frontier** is the quiet one: small garrison, low-prestige posting, a neglected fence. And on the other side, Carthaginian commercial influence — tariffs, inspections, port fees — is creeping north through Iberia towards the silver country. The boundary is a gradient of commercial relationships, shifting in Carthage's favour, generating friction Rome has no institutional vocabulary for and nobody is managing. This is the dangerous frontier.

**Why Rome never rebuilds a navy:** a road, once laid, is yours; a shipyard is kindling. "**Brundisium burned**" is the story every Roman child grows up on. The continental majority finds naval talk not risky but irrelevant — the land is delivering everything.

**The mare nostrum faction:** old-money southern Italian coastal families, the remnants of Mediterranean Rome. They burn a model Carthaginian ship every year on the Pachynus anniversary (unsanctioned, faintly embarrassing to the Senate), tell children fables of Carthaginian treachery, and say ***mare nostrum*** — "our sea" — a grievance dressed as a fact. A minority, patient as stone, waiting for the continental consensus to fracture.

**The Republic is straining:** a city-state constitution running a continental empire — extractive governors, unaccountable tax farmers, resentful Italian allies, commander-loyal legions. The crisis has not arrived by 125 BC, but the men who will make it have been born.

**The mirror:** Rome says *the land is enough* as identity; Carthage says *the sea is enough* as accounting. Each side believes the equilibrium is natural. It is merely a hundred years old.

## 4. Quick reference

| Date | Event |
|---|---|
| 260 BC | Mylae (50 Carthaginian ships lost); Bomilcar's Ostia raid; Council grants 30 ships |
| 259–258 BC | Raiding campaign ("the wheel"); Bruttium ambush; Rome loses 23 ships to storms |
| 257 BC | Battle of Cape Pachynus; Brundisium raid; Rome abandons the sea |
| 238 BC | Bomilcar dies, 57. HE GAVE CARTHAGE THE SEA |
| 229 BC | Hasdrubal Barca's Sardinia campaign (see Ch4 in context) |
| 226–225 BC | Sicily campaign; the Barcid Triumph (see Ch4 in context) |
| 170s–160s BC | Rome reaches the Pyrenees, takes eastern Iberian coastal strip |

**Names from the game's past:** Bomilcar Mago (the founder-strategist), Carthalo (cautious admiral, the painting), Hannibal (defeated at Mylae — *not that Hannibal*; in this timeline there is no "that Hannibal"), Gaius Duilius (corvus champion), Hasdrubal Barca (the Barcid Triumph).

**Punic naming:** Hannibal, Hasdrubal, Hanno, Hamilcar, Bomilcar, Bostar, Gisco, Mago recur constantly — the book jokes about it, and the game should too (petitioners needing disambiguation by port, trade, or grandfather is period-authentic comedy). On the Roman side, family attribution of any commander is disputed: Roman genealogy is competitive fiction — families claim ancestors who won and disown ancestors who lost.

## 5. Voice notes

The book's narrator is conversational, Mike Duncan-ish: present-tense asides, direct address ("Picture the scene"), dry wit, strategy framed in commercial language. That voice belongs to narration *between* turns, if used at all. **In-game documents are in-world voices** — harbour masters, factors, academy clerks, priests of Tanit, petitioning merchants — and must stay period-dry: deadpan bureaucratic register, the humour emerging from what the paperwork declines to notice, never breaking the documentary frame. A harbour master does not quip; he records, and the record is the joke. British English throughout; no anachronisms in any in-world voice.
