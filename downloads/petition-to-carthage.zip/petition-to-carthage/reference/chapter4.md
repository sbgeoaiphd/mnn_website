# Mare Non Nostrum
## An Alternate History of the Mediterranean

### Chapter Four: The Mirror

Bomilcar Mago died in 238 BC, in his own bed, which was not a thing that happened to most Carthaginian commanders.

He was fifty-seven, which was old by the standards of the time, and he had spent his last decade in a role that had no precedent in Carthaginian political life: he was, without anyone quite naming it, the permanent architect of Carthaginian naval strategy. Not an admiral anymore — he hadn't personally commanded a ship since the Cape Pachynus campaign. Not a politician, exactly, though he sat on the Council of Elders and his opinion carried weight: he had been inarguably right about the most important question of his generation. He was something more like a strategist emeritus — the man the Council consulted when they needed to understand not what to do next, but what the sea would look like in twenty years.

He spent his last years building institutions. A permanent naval academy at Carthage, one of the first of its kind in the Mediterranean, where captains were trained not just in seamanship but in logistics, coastal geography, and what a later age would call operational planning. A network of signal stations along the North African coast and the islands — Sardinia, the Balearics, western Sicily — that could relay information about ship movements in a matter of hours. A standardised shipbuilding programme that ensured Carthaginian warships were not just good but *consistent* — interchangeable parts, common designs, crews that could move from one ship to another without retraining.

He was doing the boring work that turns a military victory into a permanent strategic advantage. And he was doing it with the same merchant's logic that had won the war: naval power was not about individual ships or individual battles. It was a system. You maintained the system, and the system maintained you.

When he died, the Council declared three days of public mourning, which was unusual. They erected a monument in the great harbour — a bronze column topped with a ship's prow, mirroring, deliberately, the column the Romans had built for Duilius after Mylae. The inscription, in Punic, read: HE GAVE CARTHAGE THE SEA.

It was the right epitaph. But epitaphs have a way of becoming cages, and the generation that grew up in Bomilcar's shadow would discover that inheriting a strategy is not the same thing as understanding it.

---

By the 230s BC, Carthage was the richest city in the western world, and it was not particularly close.

Carthage had always been wealthy, and it's easy to lose sight of how dramatically the outcome of the Roman war — as the conflict of the 260s had come to be known — had changed the nature of that wealth.

Before the war, Carthaginian prosperity was commercial — trade networks, mercantile expertise, the accumulated capital of centuries of buying low and selling high across the Mediterranean. It was real wealth, but it was fragile. It depended on access, on relationships, on the willingness of other powers to let Carthaginian merchants operate in their waters. A hostile Rome, a pirate fleet, a local king who decided to renegotiate terms — any of these could disrupt the network.

After the war, Carthaginian wealth was *structural*. Carthage didn't just trade on the western Mediterranean. Carthage *owned* the western Mediterranean, in the way that a landlord owns a building. Every merchant vessel that crossed the open water between Africa, Iberia, Sardinia, and the Balearics sailed with Carthaginian permission, under Carthaginian commercial law, paying Carthaginian port fees. The navy that Bomilcar had built and his successors maintained wasn't just a military force — it was the enforcement arm of the largest maritime commercial monopoly in history.

The money was extraordinary. Carthage had always been a city of wealth, but the Carthage of the 230s was something else — a city where the merchant families built palaces that visiting Greeks compared to the courts of the Hellenistic kings, where the harbours — military and commercial together — could hold three hundred ships and were rarely less than half full, where the markets sold goods from Britain to Egypt — Atlantic tin, Nile grain, Iberian silver, all of it crossing a Carthaginian wharf at some point in the journey.

And money, as it always does, created arguments about what to do with it.

---

The fault line in Carthaginian politics had shifted.

Before the war, the great division had been between the military faction — the generals and their allies, who wanted a strong army and aggressive expansion — and the mercantile faction, who wanted to keep costs down and profits up. Bomilcar's victory had, temporarily, resolved this tension by proving that naval power *was* commercial power, that the military and mercantile interests were the same interest viewed from different angles.

But a generation of peace and prosperity had opened a new crack, and it ran right through the heart of Bomilcar's legacy.

On one side were the conservatives — the old trading families, the men who had funded Bomilcar's campaign and profited enormously from its success. Their argument was simple and, on its face, compelling: the system works. The navy controls the sea. The sea generates wealth. Wealth funds the navy. This is a virtuous circle, and the only way to break it is to do something stupid. Don't do anything stupid.

On the other side were the expansionists, and they were increasingly led by the Barcid family. The Barcids had emerged from the Roman war in an odd position. They were a military dynasty in a state that had just won its greatest victory through naval power. Their traditional base — the land army, the mercenary forces, the idea that Carthage needed to be able to fight on the ground as well as at sea — had been somewhat marginalised by Bomilcar's success. The Barcid generals hadn't been irrelevant during the war, but they hadn't been the heroes either. That grated.

And the Barcids were not stupid. They looked at the map of the western Mediterranean and saw something that the conservative merchants preferred not to think about too carefully: Carthage controlled the sea, yes. But it did not control the land.

Iberia was nominally within Carthage's sphere of influence — Carthaginian traders dominated the coast, Carthaginian silver mines produced a fortune, Carthaginian colonies dotted the shoreline from Gades to the Ebro. But the interior was a patchwork of Celtic and Iberian tribes, ungoverned, frequently hostile, and sitting on top of some of the richest mineral deposits in the known world. The Balearic Islands were Carthaginian. Sardinia was Carthaginian. But Sardinia's mountainous interior was controlled by indigenous Sardinian tribal peoples who acknowledged Carthaginian authority only when a garrison was nearby and forgot about it the moment the soldiers left.

And then there was Sicily.

Sicily, the island that had started the war, was half-finished business. The western half was Carthaginian in culture and commerce, the ports thriving under the naval umbrella. But the eastern half — Syracuse and the Greek cities — maintained a nervous independence, caught between the two great powers. And in the interior, Roman legions still held several fortified positions that they had never relinquished, even after the naval war was lost. Rome couldn't reinforce them easily, but Rome didn't abandon positions. That wasn't something Rome did.

The Barcid argument was that Carthage was a sea empire sitting on unsecured foundations. The navy was magnificent. But navies don't hold territory. You can't garrison a mine with a trireme. Sooner or later, Carthage would need to project power on land — in Iberia, in Sardinia, in Sicily — or risk watching its commercial empire hollowed out from underneath. And Sicily, they argued, was the obvious place to start. Half Carthaginian already, the Roman garrisons isolated and undersupplied, the strategic prize enormous — finish the job, and Carthage would control the central Mediterranean completely. Leave it, and Rome would always have a foothold on an island that sat across the most important sea lanes in the world.

The conservatives responded that land campaigns were expensive, unpredictable, and exactly the kind of overreach that Rome had committed when it tried to become a naval power. Stay in your domain. The sea is enough. And if anyone raised the spectre of Rome — well, look at the Romans. They were marching into the forests of Gaul. Every legion pointed north was a legion not pointed at anything Carthage cared about. Let them have their continent. It wasn't where the money was.

It was, if you squinted, a mirror image of the debate that had happened in the Roman Senate a generation earlier, only with the domains reversed.

---

Let's go to Rome.

The Rome of the 230s BC was not the Rome of the 260s. It was, in some ways, barely recognisable.

Cape Pachynus had been a catastrophe — five thousand men drowned in armour, the fleet shattered, a generation's investment sunk to the bottom of the sea. Nobody in Rome denied this. The naval faction was ruined. The shipyards at Ostia fell quiet. The dream of challenging Carthage at sea was, for any practical political purpose, dead.

Rome did not spend the decades after Pachynus sitting in the ruins feeling sorry for itself. It did something else entirely. It went north.

---

It started with Cisalpine Gaul — the Po Valley, the rich flatland south of the Alps that had been Celtic territory and a perpetual source of anxiety for Rome. The Gallic tribes there had sacked Rome itself in 390 BC, and the memory lingered like a bruise that wouldn't heal. With the legions restless and the northern frontier unsecured, the Senate authorised a campaign to subdue the region permanently. The decision barely needed making: the legions were there, the threat was real, the naval ambitions that might have pulled resources in another direction were dead — water flowing downhill.

It took ten years. It was brutal. The Gauls fought with a disregard for their own safety that Romans both admired and couldn't comprehend, duelling Roman centurions in single combat between the battle lines, dying with a theatrical grandeur that haunted Roman veterans' dreams for years afterwards. But Roman discipline ground them down, as Roman discipline always did, and within a decade the Po Valley was Roman territory, colonised and road-built and incorporated into the expanding network of Italian alliances.

Beneath the military narrative, something else was happening — something that would matter, in the long run, more than any battle. Rome was encountering a sophisticated culture for the first time since the Greeks of southern Italy, and this time it wasn't a culture mediated through trade and tutors. It was a culture being absorbed through conquest, settlement, and daily contact. These were not primitives. Gallic metalwork was extraordinary — swords, jewellery, decorative bronze that Roman craftsmen studied with a respect they would not have admitted publicly. None of this registered, yet, as a cultural shift. It registered as loot, as curiosity, as things that worked. But the seeds were in the ground.

And Rome didn't stop.

The legions pushed into Liguria, the mountainous coastal strip between Italy and southern Gaul. They crossed into northern Illyria — modern Croatia — and established a protectorate along the upper eastern Adriatic coast. Supplies for the Illyrian garrisons moved, as supplies moved everywhere in Rome's expanding network, by a combination of road and coastal shipping — grain and equipment travelling by boat across the northern Adriatic where the sea was sheltered and both coasts were friendly, then offloaded at small harbours where the roads continued inland. Nobody called this a naval operation. It was logistics. Barges and fishing boats and contracted merchants, hugging the coast, following the roads, the water supplementing the land route the way a river supplements a road that runs beside it.

Later historians — both Roman and modern — have sometimes described the post-Pachynus period as though Rome sealed itself off from the sea entirely. It didn't. Roman merchants still sailed. They traded along the Italian coast, across the Adriatic to Illyria, and — in smaller numbers — through the wider Mediterranean, where they operated within the Carthaginian commercial system, paying tariffs at Carthaginian-administered ports, following Carthaginian rules, and accepting Carthaginian inspections with the quiet resentment of men who know the game is rigged but the margins still work. There was nothing heroic about this trade. It was business, conducted by private citizens risking private capital, and Carthage tolerated it because Carthage profited from it.

What Rome did not do was invest the resources of the state in maritime capability. No new shipyards. No transport fleets. No naval dockyards. The senators who controlled the treasury had learned a specific lesson from Pachynus, and it was not "the sea is terrifying." It was "Brundisium burned." The Adriatic raid — twelve Carthaginian ships appearing from nowhere, the harbour in flames, a season's worth of infrastructure destroyed in a single dawn — had demonstrated something that no amount of courage could overcome: you do not build what your enemy can erase overnight. A road, once laid, is yours. A bridge, once built, serves whoever holds the land around it. A shipyard is a pile of timber waiting for a torch. Private merchants could accept that risk, ship by ship, cargo by cargo. The state could not, and would not, concentrate its resources in a domain where a single raid could wipe them out.

The capital that might have built a fleet built roads instead. And the roads went north.

---

Each campaign produced the same effect: more territory, more allies, more manpower, more roads, more *Rome*. And the consolation-prize narrative misses this entirely: it was working magnificently. The Po Valley was rich. The Ligurian coast opened the land route to southern Gaul and the Massaliot trade. Illyria gave access to Balkan metals and, eventually, to the edges of the Greek world. The legions were doing what legions were designed to do, in terrain that rewarded everything Roman warfare was best at: discipline, engineering, logistics, the relentless system-building that turned a battlefield into a province.

By the 230s, a new generation of Roman aristocrats had grown up in a world where the frontier was where careers were made. Their fathers had lost a fleet. They were conquering a continent, and the continent was delivering — land, wealth, glory, the triumphs that a Roman aristocrat's career was built around. The sea was not a wound for this generation. It was an irrelevance. Ask a young senator in 232 BC about Carthaginian naval supremacy and he would acknowledge it the way you might acknowledge the weather — a fact of life, not a grievance. His ambitions lay in Gaul, in Illyria, in the territories beyond the Alps that Roman scouts were just beginning to map. The sea was Carthage's business. The land was his.

Most of them didn't think about it at all.

Some of them did.

---

And now to the young man who would forge the other half of the mirror.

His name was Hasdrubal Barca, and he was twenty-four years old in 231 BC, and he was everything that Bomilcar Mago had not been.

Where Bomilcar had been cautious, analytical, a man of systems and schedules, Hasdrubal was charismatic, physical, impatient. He was the kind of young man who entered a room and rearranged it around himself. He had his family's military instincts — the Barcids bred commanders the way some families bred racehorses, with a consistency that council-aligned historians viewed with some suspicion — and he had grown up on stories of the land campaigns that Carthage had never quite committed to.

He was also deeply shaped by the war that Bomilcar had won.

Hasdrubal had been born in 255 BC, two years after Cape Pachynus. He had never known a Carthage that didn't command the sea. The navy was not, for him, an achievement — it was furniture. It was the way the world worked. What fascinated him was the *other* domain. The land. The territory that Carthage controlled on maps but didn't really hold. The interior of Iberia, wild and rich. The mountains of Sardinia, unsubdued. The contested ground in Sicily where Roman legions still stubbornly sat behind their walls.

And, above all, he was fascinated by Rome.

Not only as an enemy. Hasdrubal studied Rome the way a chess player studies a rival's games. He read Roman military history — his Greek was excellent, and Greek historians had written accounts of Rome's Italian campaigns. He admired the legions. He admired the discipline, the engineering, the way conquered ground became Roman ground within a generation. He thought Carthage could do the same thing on land that it had done at sea: build a professional, disciplined force that could project power inland and secure the territorial foundations that the navy couldn't reach.

The conservative faction in the Council of Elders thought he was a dangerous young fool who was going to get a lot of people killed.

They were half right.

---

The Sardinian campaign of 229 BC was Hasdrubal's first independent command, and it tells you almost everything you need to know about both his gifts and his limitations.

Sardinia's coast was Carthaginian. Its interior was not. The indigenous Sardinian tribal peoples — descendants of the island's ancient Bronze Age civilisation, tough mountain people who had been resisting outside control for centuries — raided Carthaginian settlements, disrupted mining operations, and generally made themselves impossible to ignore and impossible to catch. Previous Carthaginian governors had managed the problem through a combination of bribery and occasional punitive expeditions, neither of which solved anything permanently.

Hasdrubal proposed a different approach: a systematic campaign of conquest, modelled on Roman methods. Build roads. Establish fortified outposts. Push into the interior methodically, occupying ground and holding it. Turn Sardinia from a Carthaginian coast with a hostile interior into a Carthaginian island, completely and permanently.

The Council, after considerable debate — the conservatives warning of expense and overreach, the Barcid faction pushing hard — gave him eight thousand troops. Mostly Libyan infantry and Numidian cavalry, the core of Carthage's professional land forces, supplemented by Balearic slingers and Iberian mercenaries. It was a significant force for a colonial campaign, and it was Hasdrubal's to command.

He was brilliant in the mountains. What happened later has a tendency to overshadow the genuine military talent that Hasdrubal displayed in Sardinia. He adapted quickly to the terrain — narrow valleys, dense scrub, ambush country — and devised a system of mobile columns that could pursue the Sardinian war bands into ground where traditional Carthaginian forces had always bogged down. He built roads — not Roman roads, not yet, but serviceable military tracks that allowed rapid movement and resupply. He established a network of hilltop forts that gave him visibility and control over the main valleys.

In eighteen months, he pacified more of the Sardinian interior than any Carthaginian commander had managed in a century. The Sardinian tribes were not destroyed — they were too dispersed, too embedded in the landscape for that — but they were pushed back, contained, and in several cases co-opted through a combination of military pressure and surprisingly deft diplomacy. Hasdrubal was, it turned out, as good at making deals as he was at fighting.

He returned to Carthage in 227 to something approaching celebrity. The expansionists celebrated him as proof that Carthage could project land power. The conservatives grumbled about cost but couldn't argue with results. And Hasdrubal — vindicated, not yet thirty, and certain of it — began talking about Sicily.

---

This time, the Barcids won the argument.

The debate in the Council of Elders was fierce — three sessions over two weeks, if the attendance records can be trusted, the longest deliberation in living memory on a military question. But the expansionists had momentum, and they had Hasdrubal's Sardinian record, and they had the argument that was hard to answer: Sicily was half Carthaginian already. The Roman garrisons were isolated, undersupplied, maintained at enormous expense primarily because Rome was too stubborn to let them go. The Carthaginian navy controlled the waters around the island. Finishing the job was not some reckless adventure into the unknown — it was completing work that should have been done a generation ago.

The conservatives warned of cost. They warned of escalation. They pointed out that Sardinian tribesmen were not Roman legionaries. Old Adherbal, the last surviving member of Bomilcar's inner circle, told the Council flatly that the great strategist would have opposed this campaign, that Bomilcar had always said the sea was enough.

The Barcids answered that Bomilcar had been right about the sea. But the sea was secure now. The question was what to do with the security it provided. Were they to control the most important island in the Mediterranean, or leave Roman soldiers sitting on it out of some ancestral caution that no longer applied?

The vote was not close. The Council gave Hasdrubal his mandate: take Sicily, drive out the Roman garrisons, secure the island for Carthage. The navy would close the Strait of Messina to Roman military traffic. The treasury would fund twelve thousand troops — Hasdrubal's Sardinian veterans plus substantial reinforcements. It was the largest land commitment Carthage had authorised in a generation — larger even than Hasdrubal's own Sardinian force.

The conservatives, outvoted, did what outvoted factions do. They recorded their opposition and waited.

---

The Sicilian campaign began in the spring of 226 BC and went well for almost a year.

Hasdrubal landed at Lilybaeum with his twelve thousand — Libyan infantry, Numidian cavalry, Balearic slingers, Iberian and Celtiberian mercenaries, the best land force Carthage could put together. He proceeded to do exactly what the mandate required: secure the western half of the island, then push east. The western campaign was straightforward — suppressing banditry, establishing Carthaginian administrative control over towns that had been nominally Carthaginian but practically autonomous, building the network of roads and forts that had worked in Sardinia. Unglamorous, competent work.

The navy did its part. A squadron of twenty warships took station in the Strait of Messina, and the message was unambiguous: no Roman transports, no Roman reinforcements, no Roman resupply by sea. The Roman garrisons in eastern Sicily — roughly three thousand five hundred legionaries and Italian allies, spread across a handful of fortified hilltop towns — were on their own. No fresh cohorts would arrive. No replacement equipment. No siege equipment from the mainland. They could eat — the countryside around them was agricultural, and Syracuse's merchants, maintaining the city's scrupulous neutrality, would sell grain to anyone who could pay. But every legionary who fell was a legionary gone. Every javelin thrown was one fewer in the armoury. The garrison was a wasting military asset, competent and well-fed and irreplaceable.

Rome knew, in broad terms, what was happening. The Carthaginian squadron in the Strait of Messina was not a secret — merchant traffic carried the news, and the absence of dispatches from the Sicilian garrisons told its own story. But knowing and acting are different things. Rome had no fleet. It had no way to break the blockade, no way to reinforce, no way to resupply. A proposal to build transports would have meant reviving a naval programme that no one in the Senate was willing to resurrect, and no faction in Rome had the political capital or the appetite for that argument. So the Senate did what institutions do when faced with a problem they cannot solve: they noted it, deplored it, and turned their attention to the frontier where they could actually accomplish something. The campaigns in Gaul were advancing. There were triumphs to be had. Sicily, for the moment, would have to hold on its own.

By autumn, Hasdrubal controlled everything west of a line running roughly from Himera on the north coast to Gela on the south. The contested middle ground — that stretch of hilly agricultural country where Carthaginian influence faded and Roman influence began, where the towns played both sides and the local elites changed allegiance with the seasons — was falling into his hands town by town, fort by fort. His road-building and fort-building pushed the boundary steadily east, and each month the Roman perimeter shrank.

From Carthage, it looked like Sardinia all over again, only easier. From the Roman hilltops, it looked like the beginning of the end.

It was neither.

---

What happened when Hasdrubal's army entered the Roman zone of control is frequently misunderstood.

The misunderstanding goes like this: Hasdrubal, overconfident from his Sardinian victories, attacked fortified Roman positions and was thrown back. This is what happened, in the same sense that a man who walks into a river and doesn't come out has "gone swimming." It is technically true and misses everything that matters.

What actually happened was a sustained campaign of twelve to eighteen months in which a talented Carthaginian general with a better than three-to-one numerical advantage was systematically ground down by an outnumbered Roman force that was simply, comprehensively, better at fighting on land.

Not better at holding forts — though they were. The Romans didn't sit behind their walls and wait. They came out.

Roman patrols ambushed Hasdrubal's supply columns in terrain they knew better than their own names — narrow defiles between the hilltop towns, forested valleys where a century of legionaries could appear from nothing, kill the ox-drivers and scatter the pack animals, and vanish before the Carthaginian cavalry could respond. His advance parties walked into positions that looked undefended and weren't — a cleared hilltop, an abandoned farmstead, and then the javelins came from three directions at once. When he brought the Romans to pitched battle outside their fortifications — which he could only do in the narrow valleys and on the terraced hillsides where the terrain compressed the front and his numerical advantage meant nothing — the maniple rotation system did exactly what it was designed to do: the first line fought until it was tired, then stepped back through the gaps, and the second line stepped forward fresh. In open ground, with room to flank, the system would have been vulnerable to those numbers. But the Romans never offered open ground. They chose their positions the way a merchant chooses his terms — in narrow places where only so many men could fight at once, where the hills protected the flanks and the checkerboard formation could rotate without being enveloped. Two hours into an engagement in a defile, the Romans were fighting fresh. Hasdrubal's men were not.

His road-building and fort-building — the Sardinia playbook — worked against tribesmen who couldn't coordinate a response. It did not work against professionals who sortied in force, destroyed road-building parties, burned half-built stockades, and withdrew in good order to their hilltops before Hasdrubal could concentrate against them. He learned to guard his engineers with full infantry screens. The Romans learned to bypass the screens and hit the supply train instead.

He won engagements. The narrative of the Sicilian campaign has a tendency to flatten into "Romans good, Carthaginians bad," which misses the point entirely. Hasdrubal was talented. His Libyan veterans were disciplined and brave. His Numidian cavalry, in the few stretches of open ground that eastern Sicily offered, was formidable — but those few stretches were the problem. The Romans knew the ground as well as anyone alive, and they did not make the mistake of fighting where cavalry could ride them down. There were no routs. There were no columns of fleeing legionaries for the Numidians to pick apart across an open plain. Every engagement ended the same way: the Romans withdrew in order, to the next position, shields facing the enemy, at a pace that did not invite pursuit into ground the Carthaginians didn't know. Hasdrubal stormed two Roman outposts in the first year — forts that fell after hard fighting, the attackers losing two or three men for every defender. He caught a Roman patrol near Enna and wiped it out — perhaps thirty men, a skirmish, pocket change. He adapted his tactics, learned from his mistakes, and fought with the personal courage that held his army together.

But the victories, real as they were, gained land without gaining decision. A fort taken. A hilltop secured. The Roman perimeter pushed back a few miles. And the cost was always the same: in pitched battle, the terrain compression that made the fighting possible also kept the losses closer than the force ratio would suggest — a hundred and fifty Carthaginians dead, a hundred Romans, in an engagement fought on a hillside where only so many men could stand abreast. The Carthaginians were not being slaughtered. They were winning, just — taking ground, achieving the objective, watching the Romans pull back to the next line. But the Romans who pulled back were still an army. Still in formation. Still capable of doing it again tomorrow. And between the battles — between the pitched engagements where the losses were almost even — came the raids, the ambushes, the supply columns destroyed in defiles, the road-building parties scattered before the engineers could finish a single course.

Those losses were not close at all. At the level of the campaign, both armies were wearing down at roughly the same proportional rate. But Hasdrubal's dead could not be replaced from anywhere.

Because the sea was closed to Rome, yes — no reinforcements across the Strait of Messina, no resupply, no replacement legionaries. But it was closed to Hasdrubal too. The navy controlled the sea. Ships could sail freely between Carthage and Sicily. What could not cross that water was the Council's willingness to send anything on them.

The Council of Elders had funded this campaign. Twelve thousand men, the treasury allocation, the navy closing the Strait — that was the investment. They had spent what they were willing to spend. If Lilybaeum had been at risk, if the navy were threatened, the calculus might have changed. But Lilybaeum was not at risk. The navy was untroubled, the trade revenue intact. This was an optional war of expansion against some hilltop garrisons on the far side of an island Carthage already mostly controlled, and the budget was the budget. The conservatives, who had voted against the campaign and been overruled, were not about to authorise additional funds to prove they had been wrong.

And Hasdrubal did not ask. This is perhaps the most telling detail of the campaign, and it sits in the gap between what the sources say and what they don't. Hasdrubal's dispatches to Carthage — summaries survive in later compilations — report progress, report victories, report the steady contraction of the Roman perimeter. They do not request reinforcements. A proud young general, leading from the front, convinced that the next engagement would be the decisive one — if he could just take Centuripe, if he could just force them out of the last valley — was not going to send a message that read "I need more men." That message would have confirmed everything the conservatives had argued. So the dispatches said "one more push," and the Council read them and did nothing, and the army bled.

The Romans, meanwhile, had the shorter supply lines within their shrinking perimeter. Syracuse, as always, sold grain to both sides impartially. The Roman garrisons could always pay — just.

---

By the spring of 225 BC, Hasdrubal controlled roughly three-quarters of the island. Most of what he didn't hold was Syracuse and the Greek cities, which maintained their careful neutrality and were no part of his mandate. The Roman garrison — once spread across a significant stretch of the eastern interior — had been compressed to a cluster of four hilltop positions anchored on the town of Centuripe, barely twelve hundred effectives. A tiny remnant of what had been a real military presence.

He had also lost more than seven thousand men.

Not in a single catastrophe — there was no Pachynus in reverse, no day of slaughter that shocked Carthage into rethinking. That would have been easier, in a way. Easier to process, easier to learn from, easier to assign blame. What happened was worse: the slow, undramatic arithmetic of attrition. A hundred men this week. Two hundred the next. Supply column ambushed: forty dead, the grain scattered across a hillside. Outpost stormed successfully: the position was taken, but a hundred Carthaginians dead on the slope and thirty Romans dead inside the walls, and the Romans had already stripped the place of anything useful before the first assault ladder went up. Pitched battle at the Symaethus river crossing — a contested ford, the worst possible ground for an attacker — a victory, a clear, celebrated victory, Hasdrubal leading from the front, the Libyan infantry finally pushing the Roman line back after four hours of fighting — and three hundred Carthaginians dead on the field, a hundred Romans, and the Romans pulling back to the next hilltop in tight formation, ready to do the same thing tomorrow. Not a rout. Not even close. A withdrawal, orderly and professional, that conceded a river crossing and nothing else.

That was the pattern, and it never broke. Hasdrubal never lost a major engagement. He also never won one decisively — never shattered a Roman force, never turned a retreat into a slaughter, never achieved the kind of victory that actually changes the strategic picture. The Romans were a force you could defeat with numbers but could never defeat *decisively*, because the discipline meant they did not break. And an enemy that does not break is an enemy you are only barely defeating, no matter what the map says.

The army held, but it was thinning. The Balearic slingers, whose contracts — the records tell us — specified six months, had to be re-hired at double rates. Desertions crept up through the winter — not a collapse, but a steady trickle of men deciding that no bonus was going to cover the odds. Hasdrubal held it together: by personal example, by being there at the front of every assault, sleeping in the camp, eating the rations, bleeding from a wound he'd taken at the Symaethus and refused to let the surgeons properly treat because it would have meant a week away from the line.

The Council sent a delegation in the spring of 225. Not to recall him — not yet. To assess. The delegates looked at the muster rolls, looked at the supply accounts, looked at the map with its four remaining Roman dots, and asked the question that no one in the army wanted to ask out loud: was it worth it?

Hasdrubal said it was almost over. One more push. The Romans were down to their last positions. The navy controlled the sea. Sicily was Carthaginian in everything but these last few hilltops. Give him the summer.

The delegates went home. Hasdrubal got his summer.

---

He was killed in June of 225 BC, leading an assault on one of the last Roman positions west of Centuripe.

The details are contested — the Barcid tradition has him leading the final charge personally, sword in hand, while the more sober military accounts simply record that the commanding general was struck during the assault. What we can say is this: it was the final phase of the campaign. The Roman perimeter had contracted to its last positions. Hasdrubal was at the front, as he always was — because that was who he was, and because that was what held the army together. He was struck down in the fighting. He was carried from the field alive and died before nightfall.

He was thirty years old.

The remaining Carthaginian officers — experienced Libyan veterans, men who had fought the campaign from the beginning — finished what Hasdrubal had started. They did not try to be clever. They stormed the remaining positions one after another, accepting the losses Hasdrubal had always been willing to accept, without the man who had made those losses feel purposeful. It took weeks, not months. The last Roman positions, already reduced to a few hundred men, fell in a series of assaults that were still costly in absolute terms — fort-storming always is — but fast, mechanical, the Libyan professionals doing the only thing left to do. The Romans fought as they had always fought — disciplined, professional, orderly. They did not break. They were simply, finally, too few. The final positions were stormed. The last defenders were killed or captured. By the end of the summer of 225, there were no Roman soldiers on Sicily.

The Council recalled the army in autumn. Roughly three thousand men came home from the twelve thousand who had sailed. Many of them were wounded. The campaign had cost somewhere between four and five thousand talents of silver — and a talent, it should be said, is not a coin. It is twenty-six kilograms of metal. This was silver weighed in bulk, ingots on a scale. Enough to build, crew, and maintain a full battle fleet for years. Enough to fund a decade of Bomilcar's raiding campaign, the campaign that had won the naval war. Enough, frankly, to make the Council feel slightly ill when the figures were read aloud in closed session.

And what had it gained?

Sicily, yes. The island was Carthaginian. That was real.

But the western half had been Carthaginian before Hasdrubal sailed. What the campaign had actually *gained* was the eastern interior — hilly, agricultural, modestly productive. Not the wealthy ports. Not Syracuse, which maintained its Greek institutions and its careful independence, drifting gradually into the Carthaginian commercial orbit, without anyone in Syracuse ever quite deciding to. Not Catana or Tauromenium, which made their own accommodations. The land between the ports. Farms. Hill towns. A few mines. The kind of territory that would generate, over the next century, a modest agricultural surplus that would not, in any realistic accounting, ever repay the cost of taking it.

Three quarters of an army. Their best general. Thousands of talents. For some farms in the Sicilian hills.

In Carthage, the word for this kind of victory was not yet a word. It would become one.

---

A Barcid Triumph.

The phrase entered the political vocabulary of Carthage the way proverbs do — slowly, and then all at once. Within a decade of the Sicilian campaign, a "Barcid Triumph" meant any enterprise that succeeded at a cost that made success indistinguishable from failure. A merchant who cornered a market and went bankrupt doing it had achieved a Barcid Triumph. A builder who finished a palace and couldn't afford to furnish it — a Barcid Triumph. The Barcid family, understandably, did not find this amusing. But the phrase stuck, because the truth it carried was too useful to abandon.

The truth was this: Carthage had proven it could fight on land. Hasdrubal was not a fool, and his army was not a rabble. The Libyan infantry had stood against Roman legionaries and held. The Numidian cavalry had been devastating in the right terrain. Hasdrubal himself had displayed a tactical brilliance that drew grudging admiration even from Greek observers who had little natural sympathy for Carthaginian military adventurism. Carthage *could* project land power. The question was whether it could afford to.

The answer, written in the muster rolls and the treasury ledgers, was no.

And the lesson of Sicily was not the opposite of Pachynus. It was the *same* lesson, viewed from the other side.

At Pachynus, Rome had fought at sea with extraordinary courage. The corvus had worked. Roman discipline and ferocity had been real — the boarding parties that poured across the bridges had been as terrifying as any force afloat. Rome *could* fight at sea. But the cost — the ships, the trained crews, the infrastructure, the decades of institutional development required to sustain a naval campaign against a power that had been doing this for centuries — was unsustainable. The system was deeper than the weapons.

In Sicily, Carthage had fought on land with genuine competence. Hasdrubal had won engagements, adapted his tactics, held his army together through conditions that would have broken a lesser commander. Carthage *could* fight on land. But the cost — the mercenaries, the supply lines, the replacement soldiers that didn't exist, the best young general of his generation dead at thirty — was ruinous. The system was deeper than the general.

Both powers could operate in the other's domain. Neither could afford to.

---

In both cities, the lesson hardened into doctrine.

In Carthage, the school that Bomilcar had founded produced a treatise — it survives, and it is worth reading — arguing that the natural order of Mediterranean power was dual: the sea and the land, each with its master, neither capable of subduing the other at an acceptable price. The logic was commercial at its core. You could take Sicily from Rome — the proof was in hand. It would cost you nine thousand men, your best commander, and four thousand talents. Now: Rome's continental army numbers sixty thousand, and Rome replaces its losses from a citizen levy at a fraction of the cost. Calculate the cost of an Italian campaign. Calculate the cost of holding Italy after you've taken it. The numbers do not work. They can never work. Stay where the margins are.

In Rome, the reasoning was different but pointed in the same direction. The land was delivering — territory, silver, the triumphs that made a senator's name. The sea had delivered Pachynus. No senator needed a treatise to do that arithmetic.

Same conclusion. Different reasoning. Both self-serving in the way that strategic doctrines always are — each civilisation telling itself a story about why the thing it had to do was also the thing it should want to do. But the stories worked because they rested on something real: Pachynus and Sicily, the twin demonstrations that had proven, in blood and treasure, that neither power could afford to operate in the other's domain. Not because they couldn't. Because the price was too high.[^diagoras]

The sea belonged to Carthage. The land belonged to Rome.

Neither civilisation had chosen this arrangement. Both had been forced into it by the logic of their own costly ventures. But the generation that came of age in the 220s and 210s BC was the first generation to grow up believing it — not as a compromise or a humiliation, but as simply how the world worked. And belief, once it becomes the default, is a remarkably difficult thing to dislodge. Not because it's irrational — in this case it was supported by excellent strategic logic, sound economic calculation, and the vivid institutional memory of what happened when you tried to cross the line. But because every year the belief held, it became more expensive to challenge. The roads went further north. The Gallic campaigns absorbed more attention. The economy oriented itself around continental trade. The careers and fortunes and political alliances of an entire generation were built on the assumption that this was how things were.

It was not a natural law. It was a human arrangement — contingent, layered, sustained by a web of choices that all reinforced each other. But it was a very sturdy arrangement, and it would hold for a long time yet.

---

The mirror had held. Tested by both sides, paid for in full.

But we are getting ahead of ourselves.

---

::: later-voices
**Brundisium burned**: a trauma that hardens into doctrine.[^brundisium_burned]

> "My grandmother never lets anyone use her good plates." "Why?" "One of my uncles dropped one. Twenty years ago. Brundisium burned."

> "You're lending to a man whose only asset is a lease. The landlord sneezes and your money's gone. Brundisium burned."

**Barcid Triumph**: a victory that costs so much it becomes indistinguishable from defeat.[^barcid_triumph]

> "We got the olives in." "All of them?" "Every last one. Killed the donkey doing it." "Barcid Triumph." "The olives are excellent."

> "I won the lawsuit." "And?" "Lost the partnership. Lost the friendship." "Barcid Triumph?" "Barcid Triumph."

**Hill farms**: an objective so trivial it isn't worth the cost of pursuing it.[^hill_farms]

> "Don't bother. Hill farms." — A dockworker, watching a mate argue with the harbour master over a half-obol surcharge.

> "You want us to blockade their harbour?" "Yes." "Their harbour that handles a tenth of the trade ours does?" "It's strategically—" "Hill farms."
:::

---

*Next: Chapter Five — "Imperialism by Invoice"*

[^brundisium_burned]: Appendix A, 4. *Brundisium burned*.
[^barcid_triumph]: Appendix A, 5. *Barcid Triumph*.
[^hill_farms]: Appendix A, 6. *Hill farms*.
[^diagoras]: The Rhodian scholar Diagoras composed a formal analysis of this equilibrium a century and a half later. His argument is reproduced in Appendix B.
