# Minting Historical Idioms: Craft Lessons from Appendix A

Distilled from the sixteen idioms of *Mare Non Nostrum* Appendix A (`idioms.md`, ground truth) and verified against three analytical essays. Every rule below was checked against the actual entries; essay claims that didn't survive contact are noted at the end.

## 1. What makes these idioms work

**The phrase names an instance, never the lesson.** "Eleven ships", "Forty-three pieces of wood", "Hill farms" — a concrete particular from the event, usually 1–4 words, often a number or proper noun. The moral ("never dismiss the minor player") appears only in the gloss, never in the phrase. If your phrase states its own meaning, it's a maxim, not an idiom.

**The definition is one sentence naming a transferable abstraction.** "A victory that costs so much it becomes indistinguishable from defeat" (Barcid Triumph). "Having everything you don't need and nothing you do" (Wine and no grain). No proper nouns in that sentence. If you can't write it without the event, the abstraction doesn't exist.

**The abstraction must be a recurring human situation, not a historical one.** The event is merely where the pattern got named; the pattern itself must recur in kitchens, marriages, guilds. That's why "Brundisium burned" can cover a grandmother's good plates and "The Seventh" can cover a man's hairline. The event crystallises a cognition people already had — it doesn't create one.

**The origin is specific: names, dates, numbers.** Eleven ships, sixty-three ships, 12,000 troops and 3,000 returned, forty-three pieces. Concrete numbers make phrases memorable and quotable; vague origins ("a great battle") mint nothing.

**Naming is positional — decide who needed the name.** The actor abstracts; the victim remembers a one-off. Carthage named "Hasdrubal's inspections" because it *did* selective enforcement everywhere; Rome "experienced the original blockade but never had the name". "The disaster is Carthaginian to name" (Barcid Triumph). Complaints about the centre belong to the periphery: "Carthage itself doesn't say it" (Petition to Carthage) — the harbour master doesn't need a word for the fee he charges.

**Multi-party events can coin in parallel; one-sided naming is equally telling.** Wine and no grain exists natively in three languages because three cultures watched from three angles. Either pattern works — but choose deliberately and say why.

**One event can yield two idioms naming complementary halves.** Carthalo's painting / Unpaintable (the credit vs the work); Barcid Triumph / Hill farms (the cost vs the prize). If the event has two lessons, split them — don't overload one phrase.

**Same phrase, different mouths, different ground.** Brundisium burned rises from trauma in Roman mouths and from strategic confidence in Carthaginian ones — they did the burning. The Seventh is wound in Latin, pride in Celtiberian. When both sides share a phrase, specify what each brings to it.

**Idioms function as verdicts.** In use, the phrase is a complete conversational move — a two-word reply that closes, reframes or diagnoses. Often it generates the next question: "Hasdrubal's inspections — what does he actually want?" "Saltus Pass. Who flinched?" A good idiom is a tool the listener can immediately work with.

## 2. The anatomy of an entry

1. **Phrase** — 1–4 words, concrete, an instance not a moral. No puns.
2. **Definition** — one sentence, the transferable abstraction, no proper nouns.
3. **Origin note** — 2–5 sentences: specific event, specific numbers, dry narrator's voice, ending on the turn that made it proverbial ("Too costly to celebrate; too successful to regret").
4. **Ownership/register note** (italicised) — who coined it, who uses it, who conspicuously doesn't, and why; which language it lives in; valence differences by speaker position. This line is part of the meaning, not decoration.
5. **Usage examples** — 3–7 lines of dialogue. What makes a good one:
   - **Domestic and unrelated to the origin domain**: olives, roofs, apprentices, proposals, jars going empty. The further from ships and senates, the stronger the proof the idiom works.
   - **The phrase does the work**: it is the whole reply, or nearly. Nobody explains it.
   - **Range**: at least one homely line, at least one institutional/political line — the same tool at both scales.
   - **Include one subversion**: a misapplication corrected. "Eleven ships?" "No, he's just shy." "Sending silver to Cartagena?" "No, he's just stupid." "Carthalo's painting?" "No — he negotiated the original contract." The correction proves the idiom has criteria — it can be wrongly applied, therefore it means something.
   - **Show productive grammar** where natural: negation ("It's not a petition to Carthage if you ask the right question"), modification ("Saltus Pass with an army behind it"). An idiom people can bend is an idiom that lives.

## 3. Failure modes to avoid

- **Meaning = plot summary.** If the definition just retells the event, there's no abstraction and nothing to transfer.
- **Phrase = moral.** "Never trust a quiet fleet" is a fortune cookie. The good phrases are inert particulars ("Hill farms") that only mean through the story.
- **Puns and wordplay.** Zero of the sixteen rely on them. The humour lives in application, never in the coinage.
- **Usage examples that restate the definition or explain the origin.** Nobody in the examples ever says what the phrase means or recounts the event. The reader who skipped the gloss should still catch the drift from context.
- **Over-explaining valence.** State register once in the ownership note, then let the examples carry it.
- **Universal availability.** Not every phrase belongs to everyone. Some are peripheral, class-marked, or regional ("essentially unknown beyond" the Atlantic colonies). Restriction is realism; a set where everything is common currency is a tell.
- **Over-broad abstractions.** "Things go wrong" mints nothing. The abstraction must be a *shaped* situation — specific enough to be misapplied and corrected.
- **Making every idiom exotic.** Mare nostrum's captured, untranslatable, non-generalising Latin is a deliberate one-off. Most idioms must migrate freely into domestic life; mint a non-migrating "captured phrase" rarely and on purpose.

## 4. The minting quality gate

Before committing an idiom, run all five checks. Fail any one, don't mint.

1. **Abstraction test**: write the definition in one sentence with no proper nouns. Is it a situation an ordinary person hits at least yearly? If not, no.
2. **Domestic transfer test**: draft two usage lines about unrelated household matters (a marriage, a jar of olives, a leaking roof) where the phrase is essentially the whole reply. If a reader who knows only the one-sentence definition — not the event — can't follow both lines, don't mint.
3. **Subversion test**: draft one exchange where the phrase is offered and *corrected* ("X?" "No — ..."). If you can't construct a plausible misapplication, the abstraction has no edges and is too vague.
4. **Phrase-form test**: 1–4 words; a concrete instance (ideally with a number or name); not a stated lesson; no pun; shorter than its own paraphrase — the idiom must save the speaker a sentence.
5. **Ownership test**: say in one line who coined it and why *they* needed the name and the other side didn't (or why both coined it in parallel). If ownership is arbitrary, the sociolinguistic texture is fake.

## 5. Notes from the essays (verified), and what was rejected

**Kept:**
- *Asymmetric naming* — the agent of a pattern names it, the patient doesn't abstract from a single hostile act (sociolinguistics followup; verified against Hasdrubal's inspections and Barcid Triumph notes).
- *The frame precedes the name* — idioms are responsive to cognitive need, not constitutive of it; pick situations the audience already recognises (cognitive linguistics followup; verified — every entry's examples presume the listener recognises the situation instantly).
- *Exemplar-category labels* — naming a pattern by naming an instance is the core mechanism (cognitive linguistics followup; verified in Eleven ships, Forty-three pieces of wood).
- *Peripheral coinage* — the figurative language of those without power forms around what the powerful never need to name (sociolinguistics followup, via Scott's hidden transcripts; verified against Petition to Carthage).
- *Parallel coinage from multi-party events* (comparative lit followup; verified against Wine and no grain, Saltus Pass, Brundisium burned).
- *Attest distribution, don't forecast it* — note where a phrase lives now, not where it might travel (sociolinguistics followup on Forty-three pieces of wood).

**Rejected:**
- The essays' theoretical vocabulary ("provenance-marked phraseography", "isomorphic coinage", "indexical fields") — accurate-ish but unactionable; the observations survive in plain terms above.
- The comparative lit essay's fascination with mare nostrum as the exemplary case. It's the *exception*: a phrase that refuses figurative migration. Treating it as a template would produce a set of brittle, untransferable taunts. The default is migration; the capture move is a rare spice.
- Any implication that the italic provenance note is the main innovation. In practice the usage examples carry every entry; a perfect provenance note cannot rescue an idiom that fails the domestic transfer test.
