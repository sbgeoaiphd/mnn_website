# Appendix A: Historical Idioms[^linguists]

Every civilisation mints its own metaphors from its own history. In a world where Carthage won the First Punic War and survived to share the Mediterranean with Rome, the phrases people reach for come from different events than ours — but work the same way. What follows are sixteen expressions that entered common usage in this timeline, with the events that produced them and examples of how they sound in the mouths of the people who use them.

Not every phrase belongs to everyone equally. Some are used on both sides of the Mediterranean, sometimes with very different meanings. Some live mostly among the colonies that petitioned the Council and got silence back, or among the dockworkers who do the work the temple walls never show. Where a phrase comes from and who reaches for it is part of what the phrase means.

The entries are arranged in the order their events appear in the book. Each chapter closes with a small block of later voices reaching for the phrases that chapter coined; this appendix is the fuller unpacking. It is best read once you have finished the book — the entries draw freely on events from across the timeline, and many of the examples come from generations later than the events that produced them.

---

## **1. Eleven ships**

A small, overlooked force that proves decisive. Bomilcar Mago commanded a minor patrol of eleven ships off Sardinia in 260 BC — a secondary assignment with no strategic importance. When Carthage needed answers after the disaster at Mylae, those eleven ships — and the man commanding them — changed the war's direction. Never dismiss the minor player.

*Carthaginian. Used everywhere Carthaginians tell the story of Bomilcar — which is to say everywhere.*

**Usage:**
- "She's one woman with a writing desk." "Eleven ships." — Two Convocation clerks, on Arishat.
- "You're sending one cart?" "One cart with the right driver. Eleven ships."
- "The entire Ma'arabi delegation is two men and a letter of introduction." "Eleven ships. I'd hear what they have to say."
- "The youngest delegate hasn't said a word." "Eleven ships?" "No, he's just shy."
- "He's been here for years. Never says much." "But?" "Eleven ships. He's the one who closes the books."

---

## **2. Carthalo's painting**

The visible, celebrated part of a victory that someone else made possible. At Cape Pachynus, Carthalo commanded the main fleet — sixty-three ships in battle formation off the headland, waiting as the Roman convoy rounded the cape into them. The most dramatic naval engagement of the war. It was, by any measure, a spectacular action, and it was painted on temple walls across the Carthaginian world. But Carthalo was executing a plan devised by Bomilcar, attacking a convoy that Bomilcar had already crippled, destroying an escort that Bomilcar had already split. Without the two years of raiding, blockade, and intelligence-gathering that preceded it, Carthalo's sixty-three ships would have met eighty Roman warships in good order. The painting is real. The victory it depicts is incomplete.

*Carthaginian naval in origin, but the phrase belongs to those who do or witness the unpainted work. Used widely beyond the literary or political class — dockworkers, clerks, bakers, midwives. The companion of Unpaintable; the pair travel together as a matched set.*

**Usage:**
- "The foreman presents the bridge every time a dignitary visits. Didn't lay a stone." "Carthalo's painting."
- "The treaty was Arishat's — the back channels, the winter negotiations, the arm-twisting. The Convocation voted and the delegates congratulated each other." "Carthalo's painting."
- "He brings the bread to the table. She wakes at three to bake it. The children thank him." "Carthalo's painting."
- "My brother caught the fish. I carried it home. Mother thanked me." "Carthalo's painting. Tell your brother I'll buy him a drink."
- A midwife in Gades, overhearing the father being congratulated: "Carthalo's painting."
- "She's the foreman; he just signs the papers." "Carthalo's painting?" "No — he negotiated the original contract. They wouldn't exist without him."
- "Everyone congratulates me on the harvest. My wife planned the rotations, my foreman managed the workers. I just signed the contracts." "Carthalo's painting?" "Yes. They're the unpaintable ones."

*See also: **3. Unpaintable**, which names the work rather than the credit.*

---

## **3. Unpaintable**

A quality of effectiveness that resists celebration. Bomilcar Mago won the naval war against Rome between 260 and 257 BC — not in a single glorious engagement, but through two years of supply interdiction, coastal raiding, and logistical strangulation. When the decisive battle finally came at Cape Pachynus, the image that went on the temple walls was Carthalo's: sixty-three warships in battle line off the headland, the Roman escort rounding the cape into them and shattering in the shallows. Bomilcar's contribution — an ambush on a rear guard, a chase across open water, a calculated turn against scattered ships — was what made Carthalo's victory possible. None of it would make a painting. The word became, in Carthaginian usage, a term of quiet respect: the thing that actually mattered, done by the person nobody will thank.

*Carthaginian naval in origin, but the phrase belongs to those who do or witness the unpainted work. Used widely beyond the literary or political class — dockworkers, clerks, bakers, midwives.*

**Usage:**
- "Boy, we're unpaintable, aren't we." — Dockworkers finishing a hull repair at midnight, in time for the morning tide.
- "The negotiation succeeded because a Syracusan clerk spent three months reconciling tariff tables." "Unpaintable. But without those tables, the delegates would still be arguing."
- "Three women run that harbour. The harbour master gets the credit." "Unpaintable." "Buy them a drink, at least."
- "Every crew that sails from this harbour eats my bread the morning they leave. Nobody's ever put a baker on a temple wall. Unpaintable." — A woman selling bread near the Cartagena shipyards.

*See also: **2. Carthalo's painting**, which names the credit rather than the work.*

---

## **4. Brundisium burned**

A trauma that hardens into doctrine. In 257 BC, Carthaginian raiders destroyed Brundisium's harbour in a single morning — warehouses, merchant shipping, part of the waterfront district. The institutional memory of that single morning — the cost, the vulnerability, the ease with which it was all undone — became one of the reasons Rome never went back to sea. A cautionary tale that calcified into doctrine and stayed there.

The phrase carries two related meanings. (a) The psychological scar: a disaster that happened once, decades ago, that prevents you from trying again. (b) The practical warning: don't invest in something your enemy can erase overnight.

What matters most, though, is the register. Both Romans and Carthaginians use the phrase, and both reach for both meanings — but it rises from different ground in each mouth. From Romans it comes out of civilisational trauma: the wound is theirs, the warning has the weight of doctrine forged in scar tissue. From Carthaginians it comes out of strategic confidence. They did the burning. They know exactly what vulnerable assets look like because they exploited Rome's, and the same knowledge that made them effective then makes them careful now — the warning about exposed positions is the lesson they taught, turned inward. Same idiom, opposite voices: one has lived through it, the other engineered it.

*Roman and Carthaginian — both cultures coined a version from their own side of the event. Exists natively in Latin and Punic.*

**Usage:**
- (a) "He won't hire apprentices." "Why not?" "Had one steal from him, twenty years ago. Brundisium burned."
- (a) "Every time we propose expanding the coastal warehouses, someone on the committee recites the last flood. That's not analysis, that's Brundisium burned."
- (a) "He won't take his fishing boat out past the harbour mouth. His grandfather lost a ship to Carthaginian raiders." "Brundisium burned."
- (a) "My grandmother never lets anyone use her good plates." "Why?" "One of my uncles dropped one. Twenty years ago. Brundisium burned."
- (b) "The whole operation depends on the governor's goodwill." "And when the governor changes?" "Brundisium burned — build something that doesn't need his permission."
- (b) "You're lending to a man whose only asset is a lease. The landlord sneezes and your money's gone. Brundisium burned."

---

## **5. Barcid Triumph**

A victory that costs so much it becomes indistinguishable from defeat. The phrase originates from Hasdrubal Barca's conquest of Sicily in 225 BC: he finished the conquest of Sicily with 12,000 troops and barely 3,000 returned. The Council gained eastern Sicily's interior holdings — hill farms and towns — at the price of three-quarters of their army, thousands of talents of silver, and one of their finest commanders dead. Too costly to celebrate; too successful to regret.

*Carthaginian. Used everywhere from dockworkers to the Convocation. Romans know the campaign — it was their war too — but never the phrase: the disaster is Carthaginian to name.*

**Usage:**
- "He got the shop. Paid three times what it's worth and his wife left him over it." "Barcid Triumph." "He's very proud of his shop."
- "We got the olives in." "All of them?" "Every last one. Killed the donkey doing it." "Barcid Triumph." "The olives are excellent."
- "The cargo arrived on time." "The ship?" "Don't ask about the ship." "Barcid Triumph."
- "I won the lawsuit." "And?" "Lost the partnership. Lost the friendship." "Barcid Triumph?" "Barcid Triumph."
- "She came back." "After how long?" "Three years. She's not who she was." "Barcid Triumph?" "Worse. I'm not who I was either."

*See also: **6. Hill farms**, which names the prize rather than the cost.*

---

## **6. Hill farms**

An objective so trivial it isn't worth the cost of pursuing it. The Sicily campaign gained Carthage the eastern interior — some towns, some farmland in the hills. And it cost three-quarters of an army to take them. The Council, reading the ledgers, felt ill. Not the cost of the victory (that was catastrophic), but the worthlessness of the prize.

*Carthaginian. Paired with Barcid Triumph — same Sicily campaign, the other lesson. Used everywhere in the Carthaginian world.*

**Usage:**
- "It's not hill farms if the copper holds out." "It won't."
- "Don't bother. Hill farms." — A dockworker, watching a mate argue with the harbour master over a half-obol surcharge.
- "You're going to walk an hour in this heat for that?" "It's the principle." "It's hill farms is what it is."
- "You sent me to collect from a dead man." "He wasn't dead when I sent you." "Hill farms either way."
- "She's been teaching that boy for a year. He still can't hold the needle." "Hill farms, that boy." "She won't give up." "She will. Or he'll ruin the cloth and she won't need to."
- "You want us to blockade their harbour?" "Yes." "Their harbour that handles a tenth of the trade ours does?" "It's strategically—" "Hill farms."

*See also: **5. Barcid Triumph**, which names the cost rather than the prize.*

---

## **7. Mare nostrum**

A claim dressed as a fact; an aspiration that sounds like destiny.

The phrase originates from Rome's southern Italian coastal families — the old Mediterranean money whose entire identity was tied to the sea Rome had lost after Pachynus. "Our sea," they called it, speaking of the sea they were powerless to reclaim. The continental establishment used it mockingly: these families, locked in their coastal villas, insisting the Mediterranean still belonged to Rome, incapable of admitting that Rome had moved north, to land.

The phrase works three ways. (a) To the *mare nostrum* faction themselves, it is sacred — ownership performed as aspirational truth, regardless of the actual situation. (b) To the Roman mainstream, it is dismissive: the delusion of people who cannot let go. (c) The phrase has been picked up — in Latin — by Carthaginians, who carry it loaded for any Roman who gives them a target. The register runs from shrug to violent taunt. The Carthaginian use does not abstract — it stays specifically about the sea. The code-switch is the point. Said in any other language the phrase loses everything.

*Roman origin. Three valences (sacred, dismissive, Carthaginian). Always in Latin, regardless of who speaks.*

**Usage:**
- (a) "To *mare nostrum* — until it answers." — A toast among the southern Italian families. The same toast, every year, for a century and a half.
- (a) "She's said no three times." "Mare nostrum." — His friends look at each other.
- (b) "He keeps calling it 'the Iberian question.'" "It hasn't been a question for sixty years." "Mare nostrum — he'll die calling it a question."
- (b) "My grandfather's grandfather fished that bay." "Your grandfather's grandfather is dead and the harbour master is Carthaginian." "It's still our bay." "Mare nostrum." — Overheard at a tavern in a Gallic port.
- (b) "That family still sets a place at the table for the son who left for Apollonia. He's been gone thirty years and he married a Greek." "Mare nostrum."
- (c) A Carthaginian harbour master, to a Roman captain contesting a tariff: "*Mare nostrum.*" *A shrug.*
- (c) Carthaginian dockworkers at Cartagena harbour, watching a Roman merchant ship limp in with a broken mast and shredded sails: "*Mare nostrum.*"
- (c) A Roman captain in a Cartagena tavern, deep enough in the wine to forget where he is: "Every ship that comes through. Mine three times. What are they even inspecting for?" A Carthaginian at the next bench, turning to face him: "*Mare nostrum.* Whatever they want."
- (c) At a joint alliance banquet, a Roman senator from the faction raises a toast: "To *mare nostrum* — may the sea answer Rome in our children's lifetime." Down the table, the continental Romans wince. A Carthaginian delegate stands. Lifts her cup. Waits — long enough that the waiting is itself the statement. "*Mare nostrum.*" *She drinks.*
- (c) A Roman envoy: "The Convocation cannot regulate Adriatic transit without Rome's consent." A Carthaginian delegate: "*Mare nostrum.* The transit fees take effect with the spring tide."

---

## **8. Petition to Carthage**

A request that will never be answered, no matter how carefully crafted. Gaditane merchants sent the Carthaginian Council a formal petition requesting tariff reduction and autonomy — polite, detailed, financially literate. The Council formed a committee. The committee deliberated for three years and produced modest recommendations that were quietly blocked by the commercial faction. Other colonies followed with their own petitions. The same thing happened, or less. Strictly speaking, a reply was provided. In practice, it was so slow, and so empty when it finally arrived, as to be indistinguishable from silence. The phrase has outlived its political origin, but the meaning remains: communication sent to someone who will never meaningfully respond.

*Carthaginian world, but the phrase belongs to the periphery — Gades, Ma'arab, Cartagena, the interior Iberian communities. Carthage itself doesn't say it. A complaint from below.*

**Usage:**
- "I told the landlord about the roof six times." "And?" "Petition to Carthage." "Still leaking?" "In new places."
- "He proposed to her three times." "What did she say?" "Petition to Carthage."
- "The petition asks for tariff reform. Seventeen signatories." "Going to Cartagena?" "Where else?" "Petition to Carthage."
- "I'm writing one more time." "Petition to Carthage." "I know."
- "Send it to the governor." "He'll read it. It's not a petition to Carthage."
- "Write to her. It's not a petition to Carthage if you ask the right question."

---

## **9. Wine and no grain**

Having everything you don't need and nothing you do. The origin is the Turrinus expedition of 105 BC: General Turrinus led four legions into Iberia and was blockaded by Carthaginian naval enforcement. Wine shipments arrived. Grain did not. The soldiers could drink but could not eat. What the market delivered was profitable; what was necessary never came.

The phrase emerged from three angles at once. Romans, whose soldiers lived it. Carthaginians, who engineered the blockade and knew exactly which shipments to let through and which to stop. Celtiberians, who watched. Each culture coined its own version, in its own language. The image was vivid enough, and the situation universal enough, that the phrase spread everywhere.

*Roman, Carthaginian, and Celtiberian in origin — each culture coined a version from its own angle. Exists natively in all three languages.*

**Usage:**
- "He's wine and no grain, that one. Lovely to look at." — A shipwright's wife in Syracuse, on a new apprentice.
- "The delegation arrived with credentials, interpreters, and a beautiful proposal. They did not bring the authority to agree to anything." "Wine and no grain."
- "The roof is beautiful. Doesn't keep the rain out, but it's beautiful." "Wine and no grain." "I'm sleeping in the dry corner."
- "He speaks four languages." "Can he count?" "Wine and no grain — send someone who can read a ledger."

---

## **10. Saltus Pass**

A confrontation between parties operating from incompatible assumptions about authority. A Roman patrol and a Carthaginian merchant convoy met in a narrow mountain pass in 105 BC. The tribune demanded a toll. The merchant offered a gift. Neither understood the other's framework. Someone flinched. Both sides remember it as the moment the other became unreasonable.

*Trilateral in origin — a Roman patrol, a Carthaginian merchant, and his Celtiberian mercenary guards. Each side coined its own version. Exists natively in Latin, Punic, and Celtiberian.*

**Usage:**
- "I told her the price and she told me the quality. We weren't having the same conversation." "Saltus Pass."
- "The Rhodian delegates arrived expecting a trade negotiation. We arrived expecting a security briefing. Three hours before anyone realised." "Classic Saltus Pass."
- "He brought flowers. She thought he was apologising. He thought he was celebrating." "Saltus Pass. Who flinched?" "Both."
- "The Parthian envoy spoke of sovereignty. Our translator rendered it as 'commercial exclusivity.' We agreed to terms we understood differently." "This is Saltus Pass with an army behind it."
- "I said 'we should talk.' She packed a bag." "Saltus Pass." "I meant about the goat."

---

## **11. Hasdrubal's inspections**

Selectively enforcing rules that have always existed but were never applied, as a weapon. A later Hasdrubal — this one the governor of Cartagena — ordered a blockade of Roman Iberia in 105 BC. It was technically legal: he was enforcing Carthaginian commercial regulations that had been dormant for decades. The rules had always been on the books. Nobody cared until it was useful to care.

*Carthaginian — the governor's name keeps the idiom anchored to Cartagena. Used by anyone on the receiving end of selective enforcement, across the Carthaginian world. Romans experienced the original blockade but never had the name.*

**Usage:**
- "Since when do they measure the nets?" "Since you married his daughter. Hasdrubal's inspections."
- "My neighbour reported my wall for encroaching six inches into the lane. It's been there since his father's time." "Hasdrubal's inspections — what does he actually want?" "My fig tree."
- "The Convocation audited Tingis's contribution assessments. Tingis has been underpaying for a decade and nobody cared." "Until Tingis voted against the tariff revision." "Hasdrubal's inspections."
- "Since when does the matriarch correct my Gaditane accent?" "Since you broke her father's olive dish. Hasdrubal's inspections."
- "Burn anything that mentions the silver. Hanno is reviewing the old shipping records — and we voted against the harbour tax last month." "Hasdrubal's inspections will be coming."

---

## **12. The Seventh / "Going the way of the Seventh"**

An institution that evaporates through individual departures rather than dramatic collapse. Rome's Seventh Legion in Iberia didn't break, didn't rout, didn't surrender. It simply dissolved. Men left one by one — a few settled in a village, others drifted into Celtiberian communities, each making a private choice to stop being a soldier. No heroic last stand. No dramatic mutiny. Just a legion that thinned until there was almost nothing left. The veterans found it darkly comic. The civilians called it history.

The phrase carries different weight depending on where you stand. In Roman mouths it is institutional wound: the quiet failure of something that should have held. In Iberian mouths it is pride: the communities were the sponge — attractive enough that dissolution became the rational choice.

*Roman-Iberian. Used by Romans (institutional memory) and Iberians (pride); Carthaginians know the history but don't reach for the phrase. Exists natively in Latin and Celtiberian.*

**Usage:**
- "How's the guild?" "Going the way of the Seventh. Three more left last month. Nobody argues, nobody fights. They just stop coming."
- "The academy still exists. Technically." "How many students?" "Eleven this year. Twenty-three last year. Forty the year before." "The Seventh."
- "You want to keep the crew? Feed them. Respect them. Otherwise, don't act surprised in spring. The Seventh."
- "His hair? Going the way of the Seventh. He doesn't notice until the mirror tells him."
- "The olives are going the way of the Seventh. Every morning the jar is a little emptier and nobody confesses."

---

## **13. Sending silver to Cartagena**

An act of apparent absurdity that conceals urgent purpose. Apollonia's commercial faction, needing to warn Cartagena before the sack of 12 BC, redirected a ship carrying silver ingots *back* to Cartagena — the Mediterranean's greatest silver exporter. The harbour master found himself applying a tariff that had never, in living memory, been enforced. Everyone understood: the ship was not the point.

*The act was Apollonian; the phrase is Cartagenan. The absurdity (silver shipped to the silver-exporting capital) was first articulated at the receiving end, then spread across the Carthaginian commercial network.*

**Usage:**
- "He bought fish from the harbour and walked it back to the harbour." "Sending silver to Cartagena?" "No, he's just stupid."
- "She wrote to the Convocation requesting an advisory opinion on a tariff she already controls." "Silver to Cartagena — she wants them on record."
- "My cousin sailed three days to deliver a jar of olives to a farm." "Who lives on the farm?" "Ah. Silver to Cartagena."
- "He commissioned a survey of the aqueduct. The aqueduct is fine." "Silver to Cartagena — the land under it."
- "The Rhodian delegate requested a tour of the granaries. We don't export grain to Rhodes." "Silver to Cartagena. What does he actually want to see?" "The harbour defences. The granary overlooks them."

---

## **14. Carthago capta est**

A grand declaration that means nothing because there is no one to hear it. The Roman general Marcus Aemilius sacked Carthage in 12 BC and composed a three-word dispatch: *Carthage is taken*. Then he discovered there was no one to carry it. His fleet was ash. The greatest city in the western world was his, held in perfect silence.

The phrase works across cultures with three flavours. (a) Romans use it for hollow declarations — triumph with no audience, the world's applause gone. (b) Carthaginians from Carthage itself use it more acidly: for the conqueror who didn't understand what he held, or the consequences — the victory that proves the victor understood nothing. (c) The broader Punic world uses a softer version: for any victory whose victor doesn't yet grasp the full picture of what they won.

*Roman in origin, Latin always. Three flavours (hollow triumph, acid, victory-without-understanding).*

**Usage:**
- (a) "He finished the house. Beautiful. His children have all moved to Gades." "*Carthago capta est.*"
- (a) "Best meal I ever cooked. Nobody came to dinner." "*Carthago capta est*, but I'm sure the dog appreciated it."
- (a) "I win!" "*Carthago capta est*, little general — your sister stopped playing five minutes ago."
- (b) "He filed for divorce. He thinks he's free." "*Carthago capta est.*"
- (b) A Carthaginian to a Roman colleague who has just boasted of Roman naval revival: "*Carthago capta est*, my friend." *A smile.*
- (c) "Congratulations on the harbour appointment." "*Carthago capta est.* I've seen the accounts."
- (c) "I won the contract." "Did you read the maintenance terms?" "...no." "*Carthago capta est.*"

---

## **15. Strike the 'Acting'**

Accepting a fait accompli with minimal fuss. When the Carthaginian Convocation moved permanently from Carthage to Cartagena after 12 BC, nobody passed a formal resolution. The minutes simply stopped including the word "Acting." Nobody objected. The most Carthaginian way imaginable to resolve a constitutional question. The bureaucratic shrug that formalises what everyone already knows.

*Carthaginian institutional. Romans find the underlying logic alien — their legal culture demands resolutions be written down. The wider Punic world picks it up readily.*

**Usage:**
- "She's been running the shop since her father got sick." "That was two years ago." "Strike the 'Acting' — it's her shop."
- "You still call her your neighbour's wife?" "They've been separated for three years." "Strike the 'Acting.'"
- "He's been 'consulting' for the Hannonic family for a decade." "Strike the 'Acting.' He works for them." "He prefers 'consulting.'" "I'm sure he does."
- "Am I the helmsman now?" His father: "You've been the helmsman since Tuesday. Strike the 'Acting.'" — A boy in a Ma'arabi fishing village.
- "He's been 'Acting' chief scribe for two years. Since the old one died." "Strike the 'Acting.'" "There's no formal—" "There never is."

---

## **16. Forty-three pieces of wood**

Evidence so consistent and so unglamorous that nobody pays attention to it — until the accumulation becomes irrefutable. A Ma'arabi observer named Hamilcar walked the northern beaches for decades, collecting reddish driftwood of a species no one recognised. Forty-three pieces, catalogued with precision. Most were identical. Overwhelmingly tedious. Collectively undeniable. That wood had come from somewhere.

*Ma'arabi. Almost entirely contained to the Atlantic colonies, essentially unknown beyond. Latest in coinage.*

**Usage:**
- "Any single quarter's accounts look fine. Put five years side by side and the pattern is obvious." "Forty-three pieces of wood. Someone should have looked sooner."
- "The wall's been cracking since we moved in. A little more each winter. My husband says it's nothing. I say forty-three pieces of wood and we should move."
- "One petition from a provincial governor is politics. Eleven petitions from eleven governors in three years is forty-three pieces of wood."

---

[^linguists]: A linguist would object, fairly, that most of these aren't idioms in the strict sense — their origins are still visible and their meanings still traceable to the events that produced them. The technical term is *historical fixed phrase*. *Idiom* is used here in its looser, everyday sense: a phrase a community reaches for to do work that ordinary language would have to do at length. The objection is noted; the looser term retained.
